import { useState, useEffect, useCallback } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { 
  Plus, 
  UserPlus, 
  MoreVertical, 
  UserCheck,
  Heart,
  MessageCircle,
  Phone,
  Gift,
  Users as UsersIcon,
  Ban,
  Flag,
  Grid3x3,
  LayoutList,
  MoveHorizontal,
  MoveVertical
} from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { OurPeopleCarousel } from "@/components/community/OurPeopleCarousel";
import { WallStatusCarousel } from "@/components/WallStatusCarousel";
import { ELibrarySection } from "@/components/ELibrarySection";
import { FeedPost } from "@/components/FeedPost";
import { PremiumAdRotation } from "@/components/PremiumAdRotation";
import { PremiumAdCardProps } from "@/components/PremiumAdCard";
import { PeopleYouMayKnow } from "@/components/PeopleYouMayKnow";
import { communityPeople } from "@/data/communityPeopleData";
import { wallStatusPosts } from "@/data/posts";
import { useCommunityPosts, type CommunityPost } from "@/hooks/useCommunityPosts";
import { CommunityPostCard } from "@/components/community/CommunityPostCard";
import { CreateSpecialEventDialog } from "@/components/community/CreateSpecialEventDialog";
import { SendGiftDialog, GiftSelection } from "@/components/chat/SendGiftDialog";
import { ActiveCallDialog } from "@/components/chat/ActiveCallDialog";
import { MemberPreviewDialog } from "@/components/community/MemberPreviewDialog";
import { ExecutiveMember } from "@/data/communityExecutivesData";

// Profile images
import profile1 from "@/assets/profile-photo.jpg";
import profile2 from "@/assets/profile-sarah-johnson.jpg";
import profile3 from "@/assets/profile-michael-chen.jpg";
import profile4 from "@/assets/profile-emily-davis.jpg";
import profile5 from "@/assets/profile-david-martinez.jpg";
import profile6 from "@/assets/profile-james-wilson.jpg";
import profile7 from "@/assets/profile-lisa-anderson.jpg";
import profile8 from "@/assets/profile-jennifer-taylor.jpg";
import profile9 from "@/assets/profile-robert-brown.jpg";
import communityPerson1 from "@/assets/community-person-1.jpg";
import communityPerson2 from "@/assets/community-person-2.jpg";
import communityPerson3 from "@/assets/community-person-3.jpg";
import communityPerson4 from "@/assets/community-person-4.jpg";
import communityPerson5 from "@/assets/community-person-5.jpg";
import communityPerson6 from "@/assets/community-person-6.jpg";
import communityPerson7 from "@/assets/community-person-7.jpg";
import communityPerson8 from "@/assets/community-person-8.jpg";
import banner from "@/assets/profile-banner.jpg";

interface CommunityMember {
  id: string;
  name: string;
  avatar: string;
  gender: "male" | "female";
  memberSince: string;
  mutualFriends?: number;
  isOnline?: boolean;
}

// Mock community members data
const communityMembers: CommunityMember[] = [
  { id: "1", name: "Chief Emeka Okafor", avatar: communityPerson1, gender: "male", memberSince: "2015", mutualFriends: 45, isOnline: true },
  { id: "2", name: "Sarah Johnson", avatar: profile2, gender: "female", memberSince: "2016", mutualFriends: 32, isOnline: true },
  { id: "3", name: "Michael Chen", avatar: profile3, gender: "male", memberSince: "2017", mutualFriends: 28, isOnline: false },
  { id: "4", name: "Emily Davis", avatar: profile4, gender: "female", memberSince: "2018", mutualFriends: 56, isOnline: true },
  { id: "5", name: "David Martinez", avatar: profile5, gender: "male", memberSince: "2016", mutualFriends: 41, isOnline: false },
  { id: "6", name: "James Wilson", avatar: profile6, gender: "male", memberSince: "2019", mutualFriends: 23, isOnline: true },
  { id: "7", name: "Lisa Anderson", avatar: profile7, gender: "female", memberSince: "2017", mutualFriends: 38, isOnline: true },
  { id: "8", name: "Jennifer Taylor", avatar: profile8, gender: "female", memberSince: "2018", mutualFriends: 29, isOnline: false },
  { id: "9", name: "Robert Brown", avatar: profile9, gender: "male", memberSince: "2015", mutualFriends: 67, isOnline: true },
  { id: "10", name: "Dr. Ngozi Eze", avatar: communityPerson2, gender: "female", memberSince: "2015", mutualFriends: 89, isOnline: true },
  { id: "11", name: "Barr. Chidi Nwosu", avatar: communityPerson3, gender: "male", memberSince: "2016", mutualFriends: 52, isOnline: false },
  { id: "12", name: "Mrs. Amaka Johnson", avatar: communityPerson4, gender: "female", memberSince: "2017", mutualFriends: 44, isOnline: true },
];

// Birthday posts with properly mapped imageUrl and local profile images
  // Premium ad slots for community content feed
  const premiumAdSlots: PremiumAdCardProps[] = [
    {
      id: "premium-membership-feed-1",
      advertiser: {
        name: "Kerex Group Co.,Ltd",
        verified: true,
      },
      content: {
        headline: "Professional Leading Manufacturer of Heavy Equipment",
        description: "Drilling Rig | Air Compressor | Generator - Quality You Can Trust.",
        ctaText: "Get in touch",
        ctaUrl: "https://example.com/kerex",
      },
      media: {
        type: "image" as const,
        items: [{ url: "https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=1200&q=80" }],
      },
      layout: "standard" as const,
      duration: 15,
    },
    {
      id: "premium-membership-feed-2",
      advertiser: {
        name: "TechStart Business Solutions",
        verified: true,
      },
      content: {
        headline: "Scale Your Business with Cloud Solutions",
        description: "Enterprise-grade tools at startup prices. Get 50% off your first 3 months.",
        ctaText: "Start Free Trial",
        ctaUrl: "https://example.com/techstart",
      },
      media: {
        type: "image" as const,
        items: [{ url: "https://images.unsplash.com/photo-1460925895917-afdab827c52f?w=1200&q=80" }],
      },
      layout: "standard" as const,
      duration: 15,
    },
    {
      id: "premium-membership-feed-3",
      advertiser: {
        name: "Elite Fitness Center",
        verified: true,
      },
      content: {
        headline: "Get Fit, Stay Healthy",
        description: "Join Nigeria's premier fitness destination. First month 50% off!",
        ctaText: "Join Now",
        ctaUrl: "https://example.com/fitness",
      },
      media: {
        type: "carousel" as const,
        items: [
          { url: "https://images.unsplash.com/photo-1534438327276-14e5300c3a48?w=800&q=80", caption: "State-of-the-art equipment" },
          { url: "https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?w=800&q=80", caption: "Personal training" },
        ],
      },
      layout: "standard" as const,
      duration: 15,
    },
  ];

  const birthdayPosts = [
  {
    id: "birthday_1",
    title: "Happy Birthday Chief Emeka Okafor! 🎉",
    imageUrl: communityPerson1,
    author: "Chief Emeka Okafor",
    type: "Photo",
    authorImage: communityPerson1,
    timestamp: "Today",
    description: "Celebrating another blessed year of life, wisdom, and leadership!",
    likes: 245,
    comments: 89,
  },
  {
    id: "birthday_2",
    title: "Birthday Celebration - Princess Adaeze 🎂",
    imageUrl: communityPerson2,
    author: "Princess Adaeze",
    type: "Photo",
    authorImage: communityPerson2,
    timestamp: "Today",
    description: "Grateful for another year of God's blessings and grace!",
    likes: 189,
    comments: 67,
  },
  {
    id: "birthday_3",
    title: "Alhaji Musa's Birthday Wishes 🎈",
    imageUrl: communityPerson3,
    author: "Alhaji Musa Ibrahim",
    type: "Photo",
    authorImage: communityPerson3,
    timestamp: "Tomorrow",
    description: "Join me in celebrating another year of Allah's blessings!",
    likes: 156,
    comments: 45,
  },
  {
    id: "birthday_4",
    title: "Pastor Grace Birthday Thanksgiving 🙏",
    imageUrl: communityPerson4,
    author: "Pastor Grace Okonkwo",
    type: "Photo",
    authorImage: communityPerson4,
    timestamp: "This Week",
    description: "Thanksgiving service for another year of ministry and service!",
    likes: 203,
    comments: 78,
  },
  {
    id: "birthday_5",
    title: "Sarah Johnson's Birthday Party 🎊",
    imageUrl: profile2,
    author: "Sarah Johnson",
    type: "Photo",
    authorImage: profile2,
    timestamp: "This Week",
    description: "Join me for a birthday celebration filled with joy and laughter!",
    likes: 167,
    comments: 54,
  },
  {
    id: "birthday_6",
    title: "Michael Chen Birthday Celebration 🎉",
    imageUrl: profile3,
    author: "Michael Chen",
    type: "Photo",
    authorImage: profile3,
    timestamp: "Next Week",
    description: "Celebrating another year around the sun with friends and family!",
    likes: 142,
    comments: 39,
  },
  {
    id: "birthday_7",
    title: "Emily Davis Birthday Wishes 🎂",
    imageUrl: profile4,
    author: "Emily Davis",
    type: "Photo",
    authorImage: profile4,
    timestamp: "Next Week",
    description: "Grateful for all the love and blessings on my special day!",
    likes: 198,
    comments: 71,
  },
  {
    id: "birthday_8",
    title: "James Wilson's Birthday Bash 🎈",
    imageUrl: profile6,
    author: "James Wilson",
    type: "Photo",
    authorImage: profile6,
    timestamp: "Next Week",
    description: "Come celebrate with me as I turn another year older and wiser!",
    likes: 221,
    comments: 92,
  },
  {
    id: "birthday_9",
    title: "Lisa Anderson Birthday Celebration 🎊",
    imageUrl: profile7,
    author: "Lisa Anderson",
    type: "Photo",
    authorImage: profile7,
    timestamp: "Last Week",
    description: "Thank you all for the wonderful birthday wishes and love!",
    likes: 134,
    comments: 48,
  },
  {
    id: "birthday_10",
    title: "Robert Brown's Birthday Celebration 🎉",
    imageUrl: profile9,
    author: "Robert Brown",
    type: "Photo",
    authorImage: profile9,
    timestamp: "Last Month",
    description: "Had an amazing birthday celebration with loved ones!",
    likes: 178,
    comments: 63,
  },
];

// Special events posts with venue/building images from Unsplash
const specialEventPosts = [
  {
    id: "event_1",
    title: "Annual Community Fundraising Gala 2024",
    imageUrl: "https://images.unsplash.com/photo-1540575467063-178a50c2df87?w=800&auto=format&fit=crop",
    author: "Community Events Team",
    type: "Photo",
    authorImage: communityPerson5,
    timestamp: "2 days ago",
    description: "Join us for our biggest fundraising event of the year!",
    likes: 342,
    comments: 156,
  },
  {
    id: "event_2",
    title: "Youth Leadership Summit",
    imageUrl: "https://images.unsplash.com/photo-1505373877841-8d25f7d46678?w=800&auto=format&fit=crop",
    author: "Youth Development Committee",
    type: "Photo",
    authorImage: communityPerson2,
    timestamp: "5 days ago",
    description: "Empowering the next generation of community leaders",
    likes: 289,
    comments: 98,
  },
  {
    id: "event_3",
    title: "Cultural Heritage Festival",
    imageUrl: "https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?w=800&auto=format&fit=crop",
    author: "Cultural Affairs Department",
    type: "Photo",
    authorImage: communityPerson3,
    timestamp: "1 week ago",
    description: "Celebrating our rich cultural diversity and traditions",
    likes: 567,
    comments: 234,
  },
  {
    id: "event_4",
    title: "Community Health & Wellness Fair",
    imageUrl: "https://images.unsplash.com/photo-1576091160550-2173dba999ef?w=800&auto=format&fit=crop",
    author: "Health Committee",
    type: "Photo",
    authorImage: communityPerson4,
    timestamp: "1 week ago",
    description: "Free health screenings and wellness resources for all",
    likes: 423,
    comments: 187,
  },
  {
    id: "event_5",
    title: "Annual General Meeting",
    imageUrl: "https://images.unsplash.com/photo-1517457373958-b7bdd4587205?w=800&auto=format&fit=crop",
    author: "Executive Board",
    type: "Photo",
    authorImage: communityPerson1,
    timestamp: "2 weeks ago",
    description: "Review of achievements and planning for the year ahead",
    likes: 198,
    comments: 76,
  },
  {
    id: "event_6",
    title: "Community Sports Day",
    imageUrl: "https://images.unsplash.com/photo-1461896836934-ffe607ba8211?w=800&auto=format&fit=crop",
    author: "Sports & Recreation Team",
    type: "Photo",
    authorImage: communityPerson6,
    timestamp: "2 weeks ago",
    description: "Friendly competitions and family fun activities",
    likes: 512,
    comments: 203,
  },
  {
    id: "event_7",
    title: "Business Networking Event",
    imageUrl: "https://images.unsplash.com/photo-1515187029135-18ee286d815b?w=800&auto=format&fit=crop",
    author: "Economic Development Committee",
    type: "Photo",
    authorImage: communityPerson7,
    timestamp: "3 weeks ago",
    description: "Connect with local entrepreneurs and business leaders",
    likes: 367,
    comments: 145,
  },
  {
    id: "event_8",
    title: "Educational Workshop Series",
    imageUrl: "https://images.unsplash.com/photo-1524178232363-1fb2b075b655?w=800&auto=format&fit=crop",
    author: "Education Committee",
    type: "Photo",
    authorImage: communityPerson8,
    timestamp: "3 weeks ago",
    description: "Skills development and continuing education opportunities",
    likes: 445,
    comments: 167,
  },
];

interface CommunityMembershipTabProps {
  communityId?: string;
  memberCount?: number;
  onPostClick?: (post: CommunityPost) => void;
}

export function CommunityMembershipTab({ communityId, memberCount, onPostClick }: CommunityMembershipTabProps = {}) {
  const [showSpecialEventDialog, setShowSpecialEventDialog] = useState(false);
  
  // Member filter states
  const [memberGenderFilter, setMemberGenderFilter] = useState<"all" | "men" | "women">("all");
  const [friendRequestStatus, setFriendRequestStatus] = useState<Record<string, boolean>>({});

  // Special Events states
  const [specialEventsFilter, setSpecialEventsFilter] = useState<string>("all");
  const [specialEventsView, setSpecialEventsView] = useState<"normal" | "large">("normal");

  // Birthday states
  const [birthdayFilter, setBirthdayFilter] = useState<string>("today");
  const [birthdayView, setBirthdayView]   = useState<"normal" | "large">("normal");

  // Real birthday data from API
  const [birthdayMembers,   setBirthdayMembers]   = useState<any[]>([]);
  const [birthdayCounts,    setBirthdayCounts]    = useState<Record<string,number>>({});
  const [birthdayLoading,   setBirthdayLoading]   = useState(false);

  const fetchBirthdays = useCallback(async (period: string) => {
    if (!communityId) return;
    setBirthdayLoading(true);
    try {
      const res = await fetch(
        `/api/community/birthdays.php?community_id=${communityId}&period=${encodeURIComponent(period)}`,
        { credentials: 'include' }
      );
      if (res.ok) {
        const d = await res.json();
        setBirthdayMembers(d.members || []);
        if (d.counts) setBirthdayCounts(d.counts);
      }
    } catch {} finally { setBirthdayLoading(false); }
  }, [communityId]);

  useEffect(() => { fetchBirthdays(birthdayFilter); }, [communityId, birthdayFilter]);

  // E-Library states
  const [eLibraryFilter, setELibraryFilter] = useState<string>("all");
  const [visibleContentCount, setVisibleContentCount] = useState(4);

  // View All Members view mode
  const [membersViewMode, setMembersViewMode] = useState<"carousel" | "grid">("carousel");

  // Gift Dialog states
  const [giftDialogOpen, setGiftDialogOpen] = useState(false);
  const [selectedMemberForGift, setSelectedMemberForGift] = useState<{ id: string; name: string; avatar: string } | null>(null);

  // Call Dialog states
  const [callDialogOpen, setCallDialogOpen] = useState(false);
  const [selectedMemberForCall, setSelectedMemberForCall] = useState<{ id: string; name: string; avatar: string } | null>(null);

  // Block Dialog states
  const [blockDialogOpen, setBlockDialogOpen] = useState(false);
  const [selectedMemberForBlock, setSelectedMemberForBlock] = useState<{ id: string; name: string } | null>(null);

  // Report Dialog states
  const [reportDialogOpen, setReportDialogOpen] = useState(false);
  const [selectedMemberForReport, setSelectedMemberForReport] = useState<{ id: string; name: string } | null>(null);
  const [reportReason, setReportReason] = useState<string>("");
  const [reportDetails, setReportDetails] = useState<string>("");

  // Member Preview states
  const [selectedMemberForPreview, setSelectedMemberForPreview] = useState<ExecutiveMember | null>(null);
  const [showMemberPreview, setShowMemberPreview] = useState(false);

  const toggleMembersView = () => {
    setMembersViewMode(membersViewMode === "carousel" ? "grid" : "carousel");
  };

  // Convert CommunityMember to ExecutiveMember for preview
  const convertToExecutiveMember = (member: CommunityMember): ExecutiveMember => ({
    id: member.id,
    name: member.name,
    position: `${member.mutualFriends || 0} mutual friends`,
    tenure: `Member since ${member.memberSince}`,
    imageUrl: member.avatar,
    level: "officer",
    committee: "executive"
  });

  // ── Real members from API ──────────────────────────────────────────────
  const [realMembers, setRealMembers] = useState<CommunityMember[] | null>(null);
  const [membersLoading, setMembersLoading] = useState(false);

  useEffect(() => {
    if (!communityId) return;
    setMembersLoading(true);
    fetch(`/api/community/members.php?community_id=${communityId}`, { credentials: "include" })
      .then(r => r.ok ? r.json() : null)
      .then(data => {
        if (!Array.isArray(data)) return;
        setRealMembers(data.map((m: any) => ({
          id:            m.user_id,
          name:          m.name || ('@' + m.username),
          avatar:        m.profile_photo || '',
          gender:        m.gender === 'female' ? 'female' : 'male',
          memberSince:   m.joined_at ? new Date(m.joined_at).getFullYear().toString() : '2024',
          mutualFriends: 0,
          isOnline:      false,
        })));
      })
      .catch(() => {})
      .finally(() => setMembersLoading(false));
  }, [communityId]);

  // Use real members when available, fall back to mock data
  const activeMembers: CommunityMember[] = realMembers ?? communityMembers;

// Handle member card click
  const handleMemberClick = (member: CommunityMember) => {
    setSelectedMemberForPreview(convertToExecutiveMember(member));
    setShowMemberPreview(true);
  };

  // Filter members by gender
  // Compute real counts from activeMembers
  const menCount    = activeMembers.filter(m => m.gender === 'male').length;
  const womenCount  = activeMembers.filter(m => m.gender === 'female').length;
  const totalMemberCount = memberCount ?? activeMembers.length;

  const filteredMembers = activeMembers.filter((member) => {
    if (memberGenderFilter === "all") return true;
    if (memberGenderFilter === "men") return member.gender === "male";
    if (memberGenderFilter === "women") return member.gender === "female";
    return true;
  });

  // Handle add friend
  const handleAddFriend = (memberId: string, memberName: string) => {
    setFriendRequestStatus(prev => ({ ...prev, [memberId]: true }));
    toast.success(`Friend request sent to ${memberName}`);
  };

  // Handle Chat - Opens MobiChat Interface
  const handleChat = (memberId: string, memberName: string) => {
    window.dispatchEvent(new CustomEvent('openChatWithUser', {
      detail: { 
        userId: memberId,
        userName: memberName 
      }
    }));
  };

  // Handle Send Gift - Opens Gift Dialog
  const handleSendGift = (memberId: string, memberName: string, memberAvatar: string) => {
    setSelectedMemberForGift({ id: memberId, name: memberName, avatar: memberAvatar });
    setGiftDialogOpen(true);
  };

  const handleGiftSent = (giftData: GiftSelection) => {
    if (selectedMemberForGift) {
      toast.success(`Gift sent to ${selectedMemberForGift.name}!`);
    }
    setGiftDialogOpen(false);
    setSelectedMemberForGift(null);
  };

  // Handle Call - Opens Active Call Dialog
  const handleCall = (memberId: string, memberName: string, memberAvatar: string) => {
    setSelectedMemberForCall({ id: memberId, name: memberName, avatar: memberAvatar });
    setCallDialogOpen(true);
  };

  // Handle Add to Circle - Simple toast
  const handleAddToCircle = (memberName: string) => {
    toast.success(`Added ${memberName} to your circle`);
  };

  // Handle Block - Opens confirmation dialog
  const handleBlock = (memberId: string, memberName: string) => {
    setSelectedMemberForBlock({ id: memberId, name: memberName });
    setBlockDialogOpen(true);
  };

  const confirmBlock = () => {
    if (selectedMemberForBlock) {
      toast.success(`You have blocked ${selectedMemberForBlock.name}`);
    }
    setBlockDialogOpen(false);
    setSelectedMemberForBlock(null);
  };

  const handleBlockAndReport = () => {
    if (selectedMemberForBlock) {
      toast.success(`You have blocked ${selectedMemberForBlock.name}`);
      setSelectedMemberForReport({ id: selectedMemberForBlock.id, name: selectedMemberForBlock.name });
      setBlockDialogOpen(false);
      setSelectedMemberForBlock(null);
      setReportDialogOpen(true);
    }
  };

  // Handle Report - Opens report dialog
  const handleReport = (memberId: string, memberName: string) => {
    setSelectedMemberForReport({ id: memberId, name: memberName });
    setReportDialogOpen(true);
  };

  const submitReport = () => {
    if (selectedMemberForReport && reportReason) {
      toast.success(`Report submitted for ${selectedMemberForReport.name}`);
      setReportDialogOpen(false);
      setSelectedMemberForReport(null);
      setReportReason("");
      setReportDetails("");
    } else {
      toast.error("Please select a reason for reporting");
    }
  };

  // Handle member actions (for other actions like Follow, Like, etc.)
  const handleMemberAction = (action: string, memberName: string) => {
    toast.success(`${action} ${memberName}`);
  };

  // Filter content based on active filter
  // ── Real community posts from API ─────────────────────────────────────
  const { posts: realPosts, loading: postsLoading, hasMore: postsHasMore,
          loadMore: loadMorePosts, createPost, likePost, deletePost, commentOnPost, viewPost,
          uploadMedia, refresh: refreshPosts } = useCommunityPosts(communityId);

  // Filter by eLibraryFilter type
  const filteredContent = eLibraryFilter === "all"
    ? realPosts
    : realPosts.filter(p => p.type?.toLowerCase() === eLibraryFilter);

  const displayedContent = filteredContent.slice(0, visibleContentCount);

  // Birthday filter options
  const birthdayFilters = [
    { value: "today",              label: "Today" },
    { value: "this-week",          label: "This Week" },
    { value: "next-week",          label: "Next Week" },
    { value: "last-week",          label: "Last Week" },
    { value: "this-month",         label: "This Month" },
    { value: "next-month",         label: "Next Month" },
    { value: "last-month",         label: "Last Month" },
    { value: "this-three-months",  label: "This 3 Months" },
    { value: "next-three-months",  label: "Next 3 Months" },
    { value: "last-three-months",  label: "Last 3 Months" },
  ];

  return (
    <div className="space-y-6 pb-6">
      {/* 1. Our People, Our Strength */}
      <OurPeopleCarousel items={communityPeople} />

      {/* 2. View All Members Section */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-xl sm:text-2xl font-bold">{`View All Members (${totalMemberCount.toLocaleString()})`}</h2>
          <button
            onClick={toggleMembersView}
            className="p-2 rounded-md hover:bg-muted transition-colors"
            title={membersViewMode === "carousel" ? "Switch to grid view" : "Switch to carousel view"}
          >
            {membersViewMode === "carousel" ? (
              <Grid3x3 className="h-5 w-5" />
            ) : (
              <LayoutList className="h-5 w-5" />
            )}
          </button>
        </div>

        {/* Gender Filter Tabs */}
        <div className="flex items-center gap-4">
          <Button
            variant={memberGenderFilter === "men" ? "default" : "outline"}
            size="sm"
            onClick={() => setMemberGenderFilter("men")}
            className="rounded-full text-base font-semibold px-4"
          >
            {`Men (${menCount})`}
          </Button>
          <span className="text-lg font-bold text-muted-foreground">|</span>
          <Button
            variant={memberGenderFilter === "women" ? "default" : "outline"}
            size="sm"
            onClick={() => setMemberGenderFilter("women")}
            className="rounded-full text-base font-semibold px-4"
          >
            {`Women (${womenCount})`}
          </Button>
          {memberGenderFilter !== "all" && (
            <>
              <span className="text-muted-foreground font-medium">|</span>
              <Button
                variant="ghost"
                size="sm"
                onClick={() => setMemberGenderFilter("all")}
                className="text-xs"
              >
                Clear Filter
              </Button>
            </>
          )}
        </div>

        {/* Members Carousel/Grid */}
        <div className="relative">
          {membersViewMode === "carousel" ? (
            <div className="flex gap-3 overflow-x-auto pb-3 scrollbar-thin scrollbar-thumb-primary/20 scrollbar-track-transparent">
              {filteredMembers.map((member) => (
                <Card 
                  key={member.id} 
                  className="flex-shrink-0 w-[170px] sm:w-[190px] p-4 space-y-3 hover:shadow-lg transition-shadow"
                >
                  {/* Clickable Avatar & Info */}
                  <div 
                    className="cursor-pointer"
                    onClick={() => handleMemberClick(member)}
                  >
                    {/* Avatar */}
                    <div className="relative mx-auto w-20 h-20 sm:w-24 sm:h-24">
                      <Avatar className="w-full h-full border-2 border-primary/20">
                        <AvatarImage src={member.avatar} alt={member.name} className="object-cover" />
                        <AvatarFallback>{member.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      {member.isOnline && (
                        <div className="absolute bottom-1 right-1 h-3 w-3 bg-green-500 rounded-full border-2 border-background" />
                      )}
                    </div>

                    {/* Name & Info */}
                    <div className="text-center space-y-1 mt-3">
                      <h4 className="font-bold text-base truncate" title={member.name}>
                        {member.name}
                      </h4>
                      <p className="text-sm font-medium text-muted-foreground">
                        Since {member.memberSince}
                      </p>
                      {member.mutualFriends && (
                        <p className="text-sm font-semibold text-primary">
                          {member.mutualFriends} mutual
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-2">
                    {friendRequestStatus[member.id] ? (
                      <Button 
                        size="sm" 
                        variant="secondary" 
                        className="flex-1 text-sm font-semibold"
                        disabled
                      >
                        <UserCheck className="h-4 w-4 mr-1" />
                        Sent
                      </Button>
                    ) : (
                      <Button
                        size="sm"
                        className="flex-1 text-sm font-semibold"
                        onClick={() => handleAddFriend(member.id, member.name)}
                      >
                        <UserPlus className="h-4 w-4 mr-1" />
                        Add
                      </Button>
                    )}
                    
                    {/* Do More Dropdown */}
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button size="sm" variant="outline" className="px-2">
                          <MoreVertical className="h-4 w-4" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-40">
                        <DropdownMenuItem onClick={() => handleMemberAction("Following", member.name)}>
                          <UserCheck className="h-4 w-4 mr-2" />
                          Follow
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleMemberAction("Liked", member.name)}>
                          <Heart className="h-4 w-4 mr-2" />
                          Like
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleChat(member.id, member.name)}>
                          <MessageCircle className="h-4 w-4 mr-2" />
                          Chat
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleCall(member.id, member.name, member.avatar)}>
                          <Phone className="h-4 w-4 mr-2" />
                          Call
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleSendGift(member.id, member.name, member.avatar)}>
                          <Gift className="h-4 w-4 mr-2" />
                          Send Gift
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleAddToCircle(member.name)}>
                          <UsersIcon className="h-4 w-4 mr-2" />
                          Add to Circle
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={() => handleBlock(member.id, member.name)}
                          className="text-destructive"
                        >
                          <Ban className="h-4 w-4 mr-2" />
                          Block
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={() => handleReport(member.id, member.name)}
                          className="text-destructive"
                        >
                          <Flag className="h-4 w-4 mr-2" />
                          Report
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </Card>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 gap-3">
              {filteredMembers.map((member) => (
                <Card 
                  key={member.id} 
                  className="p-3 space-y-2 hover:shadow-lg transition-shadow"
                >
                  {/* Clickable Avatar & Info */}
                  <div 
                    className="cursor-pointer"
                    onClick={() => handleMemberClick(member)}
                  >
                    {/* Avatar */}
                    <div className="relative mx-auto w-16 h-16 sm:w-20 sm:h-20">
                      <Avatar className="w-full h-full border-2 border-primary/20">
                        <AvatarImage src={member.avatar} alt={member.name} className="object-cover" />
                        <AvatarFallback>{member.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      {member.isOnline && (
                        <div className="absolute bottom-0 right-0 h-3 w-3 bg-green-500 rounded-full border-2 border-background" />
                      )}
                    </div>

                    {/* Name & Info */}
                    <div className="text-center space-y-0.5 mt-2">
                      <h4 className="font-semibold text-xs sm:text-sm truncate" title={member.name}>
                        {member.name}
                      </h4>
                      <p className="text-[10px] sm:text-xs text-muted-foreground">
                        Since {member.memberSince}
                      </p>
                      {member.mutualFriends && (
                        <p className="text-[10px] sm:text-xs text-primary">
                          {member.mutualFriends} mutual
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Action Buttons */}
                  <div className="flex gap-1">
                    {friendRequestStatus[member.id] ? (
                      <Button 
                        size="sm" 
                        variant="secondary" 
                        className="flex-1 text-[10px] sm:text-xs h-7"
                        disabled
                      >
                        <UserCheck className="h-3 w-3 mr-1" />
                        Sent
                      </Button>
                    ) : (
                      <Button
                        size="sm"
                        className="flex-1 text-[10px] sm:text-xs h-7"
                        onClick={() => handleAddFriend(member.id, member.name)}
                      >
                        <UserPlus className="h-3 w-3 mr-1" />
                        Add
                      </Button>
                    )}
                    
                    {/* Do More Dropdown */}
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button size="sm" variant="outline" className="px-1.5 h-7">
                          <MoreVertical className="h-3 w-3" />
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent align="end" className="w-40">
                        <DropdownMenuItem onClick={() => handleMemberAction("Following", member.name)}>
                          <UserCheck className="h-4 w-4 mr-2" />
                          Follow
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleMemberAction("Liked", member.name)}>
                          <Heart className="h-4 w-4 mr-2" />
                          Like
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleChat(member.id, member.name)}>
                          <MessageCircle className="h-4 w-4 mr-2" />
                          Chat
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleCall(member.id, member.name, member.avatar)}>
                          <Phone className="h-4 w-4 mr-2" />
                          Call
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleSendGift(member.id, member.name, member.avatar)}>
                          <Gift className="h-4 w-4 mr-2" />
                          Send Gift
                        </DropdownMenuItem>
                        <DropdownMenuItem onClick={() => handleAddToCircle(member.name)}>
                          <UsersIcon className="h-4 w-4 mr-2" />
                          Add to Circle
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={() => handleBlock(member.id, member.name)}
                          className="text-destructive"
                        >
                          <Ban className="h-4 w-4 mr-2" />
                          Block
                        </DropdownMenuItem>
                        <DropdownMenuItem 
                          onClick={() => handleReport(member.id, member.name)}
                          className="text-destructive"
                        >
                          <Flag className="h-4 w-4 mr-2" />
                          Report
                        </DropdownMenuItem>
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </div>
                </Card>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* 3. Create Special Event Posts Button */}
      <button
        onClick={() => setShowSpecialEventDialog(true)}
        className="w-full p-4 sm:p-5 bg-card border-2 border-success/30 rounded-lg hover:border-success/50 hover:shadow-md transition-all group"
      >
        <div className="flex items-center justify-center gap-2 text-foreground">
          <span className="font-medium text-sm sm:text-base">Create Special Event Posts</span>
          <Plus className="h-5 w-5 group-hover:scale-110 transition-transform" />
        </div>
      </button>
      
      <CreateSpecialEventDialog
        open={showSpecialEventDialog}
        onOpenChange={setShowSpecialEventDialog}
        communityId={communityId}
        onPost={async (payload) => {
          const ok = await createPost(payload);
          if (ok) refreshPosts();
          return ok;
        }}
        uploadMedia={uploadMedia}
      />

      {/* Send Gift Dialog */}
      <SendGiftDialog
        isOpen={giftDialogOpen}
        onClose={() => {
          setGiftDialogOpen(false);
          setSelectedMemberForGift(null);
        }}
        recipientName={selectedMemberForGift?.name || ""}
        onSendGift={handleGiftSent}
      />

      {/* Active Call Dialog */}
      <ActiveCallDialog
        isOpen={callDialogOpen}
        onClose={() => {
          setCallDialogOpen(false);
          setSelectedMemberForCall(null);
        }}
        recipientName={selectedMemberForCall?.name || ""}
        recipientAvatar={selectedMemberForCall?.avatar}
      />

      {/* Block Confirmation Dialog */}
      <AlertDialog open={blockDialogOpen} onOpenChange={setBlockDialogOpen}>
        <AlertDialogContent className="max-w-[90vw] sm:max-w-md">
          <AlertDialogHeader>
            <AlertDialogTitle className="flex items-center gap-2">
              <Ban className="h-5 w-5 text-destructive" />
              Block User
            </AlertDialogTitle>
            <AlertDialogDescription className="text-left space-y-2">
              <p>Are you sure you want to block <strong>{selectedMemberForBlock?.name}</strong>?</p>
              <p className="text-sm text-muted-foreground">They will no longer be able to:</p>
              <ul className="text-sm text-muted-foreground list-disc list-inside space-y-1">
                <li>See your posts</li>
                <li>Send you messages</li>
                <li>Find your profile</li>
              </ul>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex-col sm:flex-row gap-2">
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={confirmBlock} className="bg-destructive hover:bg-destructive/90">
              Block
            </AlertDialogAction>
            <AlertDialogAction onClick={handleBlockAndReport} className="bg-destructive hover:bg-destructive/90">
              Block & Report
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Report Dialog */}
      <Dialog open={reportDialogOpen} onOpenChange={setReportDialogOpen}>
        <DialogContent className="max-w-[90vw] sm:max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Flag className="h-5 w-5 text-destructive" />
              Report User
            </DialogTitle>
            <p className="text-sm text-muted-foreground">{selectedMemberForReport?.name}</p>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <p className="text-sm font-medium">Why are you reporting this user?</p>
            <RadioGroup value={reportReason} onValueChange={setReportReason} className="space-y-2">
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="spam" id="spam" />
                <Label htmlFor="spam">Spam</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="harassment" id="harassment" />
                <Label htmlFor="harassment">Harassment or bullying</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="inappropriate" id="inappropriate" />
                <Label htmlFor="inappropriate">Inappropriate content</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="fake" id="fake" />
                <Label htmlFor="fake">Fake or impersonation</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="scam" id="scam" />
                <Label htmlFor="scam">Scam or fraud</Label>
              </div>
              <div className="flex items-center space-x-2">
                <RadioGroupItem value="other" id="other" />
                <Label htmlFor="other">Other</Label>
              </div>
            </RadioGroup>
            <div className="space-y-2">
              <Label htmlFor="details">Additional details (optional)</Label>
              <Textarea
                id="details"
                placeholder="Provide more context..."
                value={reportDetails}
                onChange={(e) => setReportDetails(e.target.value)}
                className="min-h-[80px]"
              />
            </div>
          </div>
          <DialogFooter className="flex-col sm:flex-row gap-2">
            <Button variant="outline" onClick={() => setReportDialogOpen(false)}>
              Cancel
            </Button>
            <Button onClick={submitReport} className="bg-destructive hover:bg-destructive/90">
              Submit Report
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

        {/* 4. Special Events Section */}
        <WallStatusCarousel
          items={(realPosts.filter(p => p.type === 'special-event' || p.type === 'event')).map(p => ({
            id: p.id, title: p.title || p.description || 'Special Event',
            imageUrl: p.imageUrl, description: p.description,
            author: p.author, authorImage: p.authorImage, timestamp: p.timestamp,
            likes: p.likes, comments: p.comments, views: String(p.views || 0),
            type: p.type, userId: p.authorId, isOwner: p.isOwner,
          }))}
          title="Special Events"
          view={specialEventsView}
          filter={specialEventsFilter}
          onViewChange={setSpecialEventsView}
          onFilterChange={setSpecialEventsFilter}
          onDelete={deletePost}
          onItemClick={(item) => onPostClick && onPostClick(realPosts.find(p => p.id === item.id) || {
            id: item.id, title: item.title || '', description: item.description || '',
            type: item.type || 'event', imageUrl: item.imageUrl, videoUrl: undefined,
            author: item.author || '', authorId: item.userId || '', authorImage: item.authorImage,
            userId: item.userId || '', timestamp: item.timestamp || '', likes: item.likes || 0,
            comments: item.comments || 0, views: 0, isPinned: false, isLiked: false, isOwner: false,
          } as any)}
          showViewToggle={true}
          showFilterCounts={true}
        />

      {/* 5. Members' Birthdays Section */}
      <section className="space-y-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h2 className="text-lg sm:text-xl font-semibold">Members' Birthdays 🎂</h2>
            {birthdayCounts[birthdayFilter] !== undefined && (
              <Badge variant="secondary" className="text-xs">
                {birthdayCounts[birthdayFilter]}
              </Badge>
            )}
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => setBirthdayView(birthdayView === "normal" ? "large" : "normal")}
            className="gap-1.5"
            title={birthdayView === "normal" ? "Switch to Vertical View" : "Switch to Horizontal View"}
          >
            {birthdayView === "normal" ? (
              <MoveHorizontal className="h-4 w-4" />
            ) : (
              <MoveVertical className="h-4 w-4" />
            )}
          </Button>
        </div>

        {/* Birthday Filter Tabs — first 4 visible, rest in dropdown */}
        <div className="flex flex-wrap gap-2">
          {birthdayFilters.slice(0, 4).map((filter) => {
            const count = birthdayCounts[filter.value] ?? 0;
            return (
              <Button
                key={filter.value}
                variant={birthdayFilter === filter.value ? "default" : "outline"}
                size="sm"
                onClick={() => setBirthdayFilter(filter.value)}
                className="text-xs sm:text-sm"
              >
                {filter.label}
                {count > 0 && (
                  <Badge variant={birthdayFilter === filter.value ? "secondary" : "outline"} className="ml-1.5 text-[10px] h-4 px-1">
                    {count}
                  </Badge>
                )}
              </Button>
            );
          })}

          {/* More Dropdown */}
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button
                variant={birthdayFilters.slice(4).some(f => f.value === birthdayFilter) ? "default" : "outline"}
                size="sm"
                className="text-xs sm:text-sm"
              >
                More ···
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="start" className="min-w-[180px]">
              {birthdayFilters.slice(4).map((filter) => {
                const count = birthdayCounts[filter.value] ?? 0;
                return (
                  <DropdownMenuItem
                    key={filter.value}
                    onClick={() => setBirthdayFilter(filter.value)}
                    className={birthdayFilter === filter.value ? "bg-primary text-primary-foreground" : ""}
                  >
                    <span className="flex-1">{filter.label}</span>
                    {count > 0 && (
                      <Badge variant="secondary" className="ml-2 text-[10px]">{count}</Badge>
                    )}
                  </DropdownMenuItem>
                );
              })}
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {/* Birthday Members */}
        {birthdayLoading ? (
          <div className="flex justify-center py-8">
            <div className="h-6 w-6 border-2 border-primary border-t-transparent rounded-full animate-spin" />
          </div>
        ) : birthdayMembers.length === 0 ? (
          <div className="text-center py-10 space-y-2">
            <p className="text-3xl">🎂</p>
            <p className="text-sm font-medium text-muted-foreground">
              No birthdays for{" "}
              {birthdayFilters.find(f => f.value === birthdayFilter)?.label ?? birthdayFilter}
            </p>
            <p className="text-xs text-muted-foreground">
              Members' birthday dates are filled in from their profile
            </p>
          </div>
        ) : (
          <div className={birthdayView === "normal"
            ? "flex gap-3 overflow-x-auto pb-2 snap-x snap-mandatory scrollbar-thin scrollbar-thumb-muted"
            : "grid grid-cols-2 sm:grid-cols-3 gap-3"}>
            {birthdayMembers.map((member) => (
              <div
                key={member.id}
                className={`shrink-0 snap-start ${birthdayView === "normal" ? "w-36" : "w-full"} relative`}
              >
                <div className="relative rounded-xl overflow-hidden border border-border bg-card hover:shadow-md transition-shadow group">
                  {/* Avatar */}
                  <div className="relative aspect-[3/4] bg-gradient-to-b from-primary/10 to-muted overflow-hidden">
                    {member.profile_photo ? (
                      <img
                        src={member.profile_photo}
                        alt={member.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-4xl font-bold text-muted-foreground/30">
                        {(member.name || "?")[0]}
                      </div>
                    )}
                    {/* Today badge */}
                    {member.is_today && (
                      <div className="absolute top-2 left-0 right-0 flex justify-center">
                        <span className="bg-yellow-400 text-yellow-900 text-[10px] font-bold px-2 py-0.5 rounded-full shadow">
                          🎂 Today!
                        </span>
                      </div>
                    )}
                  </div>
                  {/* Info */}
                  <div className="p-2 text-center">
                    <p className="text-xs font-semibold truncate">{member.name}</p>
                    <p className="text-[10px] text-primary font-medium mt-0.5">{member.birthday_display}</p>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </section>

        {/* 6. Community Content */}
        <ELibrarySection
          activeFilter={eLibraryFilter}
          onFilterChange={setELibraryFilter}
          title="Community Content"
        />

        {/* Community Content Items */}
        {postsLoading && realPosts.length === 0 ? (
          <div className="flex justify-center py-8">
            <div className="h-6 w-6 border-2 border-primary border-t-transparent rounded-full animate-spin" />
          </div>
        ) : realPosts.length === 0 ? (
          <div className="text-center py-10 text-sm text-muted-foreground">
            No community content yet
          </div>
        ) : null}
        <div className="space-y-6">
          {displayedContent.map((post, index) => (
            <div key={post.id}>
              <CommunityPostCard
                post={post}
                onLike={likePost}
                onDelete={deletePost}
                onComment={commentOnPost}
                onView={viewPost}
                onOpenDetail={onPostClick}
              />
              {/* Insert premium ad after every 4 posts */}
              {(index + 1) % 4 === 0 && index < displayedContent.length - 1 && (
                <div className="my-8">
                  <PremiumAdRotation
                    slotId={`membership-feed-premium-${Math.floor((index + 1) / 4)}`}
                    ads={[premiumAdSlots[Math.floor((index + 1) / 4) % premiumAdSlots.length]]}
                    context="feed"
                  />
                </div>
              )}
              {/* Insert People You May Know after every 10 posts */}
              {(index + 1) % 10 === 0 && index < displayedContent.length - 1 && (
                <div className="my-6">
                  <PeopleYouMayKnow />
                </div>
              )}
            </div>
          ))}
        </div>

        {/* Load More / Less buttons */}
        {filteredContent.length > visibleContentCount && (
          <div className="flex justify-center mt-4">
            <Button
              variant="link"
              onClick={() => setVisibleContentCount(prev => prev + 4)}
            >
              ...more
            </Button>
          </div>
        )}
        {visibleContentCount > 4 && filteredContent.length > 4 && (
          <div className="flex justify-center">
            <Button 
              variant="link" 
              onClick={() => setVisibleContentCount(4)}
            >
              Less...
            </Button>
          </div>
        )}

        {/* Member Preview Dialog */}
        <MemberPreviewDialog
          member={selectedMemberForPreview}
          open={showMemberPreview}
          onOpenChange={setShowMemberPreview}
        />
    </div>
  );
}