import React, { useState, useEffect } from "react";
import { X, Video, Music, Images, Plus } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Badge } from "@/components/ui/badge";
import { Drawer, DrawerContent, DrawerHeader, DrawerTitle, DrawerFooter, DrawerClose } from "@/components/ui/drawer";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ContentType, AdminContentItem } from "@/data/adminContentData";
import { ImageUpload } from "./ImageUpload";
import { Image as ImageIcon } from "lucide-react";

interface ContentFormDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  contentType: ContentType;
  editingItem?: AdminContentItem | null;
  onSubmit: (data: Partial<AdminContentItem>) => void;
}

const contentTypeLabels: Record<ContentType, string> = {
  news: "News",
  event: "Event",
  article: "Article",
  vibe: "Vibe"
};

const newsCategories = ["Announcements", "Events", "Updates", "General", "Affairs"];
const eventTypes = ["Conference", "Workshop", "Meetup", "Celebration", "Fundraiser", "Social"];
const meetingModes = ["indoor", "outdoor", "virtual", "hybrid"] as const;
const platformVenueOptions = ["mobi-meeting", "zoom-meeting", "other"] as const;
const audienceTypes = ["Members Only", "Public", "VIP", "Families", "Youth", "Seniors"];
const articleCategories = ["Community News", "Culture", "Development", "Education", "Opinion"];
const mediaTypes = ["video", "photo", "audio", "gallery"] as const;

export function ContentFormDialog({
  open,
  onOpenChange,
  contentType,
  editingItem,
  onSubmit
}: ContentFormDialogProps) {
  const [formData, setFormData] = useState<Partial<AdminContentItem> & { platformVenue?: string; customPlatformVenue?: string; venueAddress?: string }>({
    type: contentType,
    title: "",
    description: "",
    content: "",
    category: "",
    featured: false,
    spotlight: false,
    mediaType: "photo",
    venueType: "indoor",
    platformVenue: "mobi-meeting",
    customPlatformVenue: "",
    venueAddress: "",
    tags: [],
  });
  const [newTag, setNewTag] = useState("");
  const [publishOption, setPublishOption] = useState<"draft" | "pending" | "published">("draft");
  const [showCustomCategory, setShowCustomCategory] = useState(false);
  const [customCategory, setCustomCategory] = useState("");

  useEffect(() => {
    if (editingItem) {
      setFormData({
        ...editingItem,
        tags: editingItem.tags || [],
      });
      setPublishOption(editingItem.status === "published" ? "published" : editingItem.status === "pending" ? "pending" : "draft");
    } else {
      setFormData({
        type: contentType,
        title: "",
        description: "",
        content: "",
        category: "",
        featured: false,
        spotlight: false,
        mediaType: "photo",
        venueType: "indoor",
        platformVenue: "mobi-meeting",
        customPlatformVenue: "",
        venueAddress: "",
        tags: [],
      });
      setPublishOption("draft");
      setShowCustomCategory(false);
      setCustomCategory("");
    }
  }, [editingItem, contentType, open]);

  const handleSubmit = () => {
    const data: Partial<AdminContentItem> = {
      ...formData,
      type: contentType,
      status: publishOption,
      submittedAt: publishOption === "pending" ? new Date() : undefined,
      publishedAt: publishOption === "published" ? new Date() : undefined,
    };
    onSubmit(data);
    onOpenChange(false);
  };

  const addTag = () => {
    if (newTag.trim() && !formData.tags?.includes(newTag.trim())) {
      setFormData(prev => ({
        ...prev,
        tags: [...(prev.tags || []), newTag.trim()]
      }));
      setNewTag("");
    }
  };

  const removeTag = (tag: string) => {
    setFormData(prev => ({
      ...prev,
      tags: prev.tags?.filter(t => t !== tag) || []
    }));
  };

  const renderTypeSpecificFields = () => {
    switch (contentType) {
      case "news":
        return (
          <>
            <div className="space-y-2">
              <Label>Category</Label>
              <Select 
                value={showCustomCategory ? "other" : (formData.category || "")} 
                onValueChange={(v) => {
                  if (v === "other") {
                    setShowCustomCategory(true);
                  } else {
                    setShowCustomCategory(false);
                    setCustomCategory("");
                    setFormData(prev => ({ ...prev, category: v }));
                  }
                }}
              >
                <SelectTrigger><SelectValue placeholder="Select category" /></SelectTrigger>
                <SelectContent>
                  {newsCategories.map(cat => (
                    <SelectItem key={cat} value={cat.toLowerCase()}>{cat}</SelectItem>
                  ))}
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
              {showCustomCategory && (
                <Input
                  placeholder="Enter custom category..."
                  value={customCategory}
                  onChange={(e) => {
                    setCustomCategory(e.target.value);
                    setFormData(prev => ({ ...prev, category: e.target.value.toLowerCase() }));
                  }}
                  className="mt-2 text-base"
                  style={{ touchAction: 'manipulation' }}
                  onClick={(e) => e.stopPropagation()}
                  autoComplete="off"
                />
              )}
            </div>
            <div className="flex items-center justify-between">
              <Label>Featured News</Label>
              <Switch checked={formData.featured} onCheckedChange={(v) => setFormData(prev => ({ ...prev, featured: v }))} />
            </div>
          </>
        );

      case "event":
        return (
          <>
            <div className="space-y-2">
              <Label>Event Type</Label>
              <Select 
                value={showCustomCategory ? "other" : (formData.category || "")} 
                onValueChange={(v) => {
                  if (v === "other") {
                    setShowCustomCategory(true);
                  } else {
                    setShowCustomCategory(false);
                    setCustomCategory("");
                    setFormData(prev => ({ ...prev, category: v }));
                  }
                }}
              >
                <SelectTrigger><SelectValue placeholder="Select event type" /></SelectTrigger>
                <SelectContent>
                  {eventTypes.map(type => (
                    <SelectItem key={type} value={type.toLowerCase()}>{type}</SelectItem>
                  ))}
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
              {showCustomCategory && (
                <Input
                  placeholder="Enter custom event type..."
                  value={customCategory}
                  onChange={(e) => {
                    setCustomCategory(e.target.value);
                    setFormData(prev => ({ ...prev, category: e.target.value.toLowerCase() }));
                  }}
                  className="mt-2 text-base"
                  style={{ touchAction: 'manipulation' }}
                  onClick={(e) => e.stopPropagation()}
                  autoComplete="off"
                />
              )}
            </div>
            <div className="space-y-2">
              <Label>Meeting Mode</Label>
              <Select value={formData.venueType || "indoor"} onValueChange={(v) => setFormData(prev => ({ ...prev, venueType: v as typeof meetingModes[number] }))}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="outdoor">Outdoor</SelectItem>
                  <SelectItem value="indoor">Indoor</SelectItem>
                  <SelectItem value="virtual">Virtual</SelectItem>
                  <SelectItem value="hybrid">Hybrid</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2">
              <Label>Platform/Venue</Label>
              <Select 
                value={formData.platformVenue || "mobi-meeting"} 
                onValueChange={(v) => setFormData(prev => ({ 
                  ...prev, 
                  platformVenue: v,
                  venue: v === "mobi-meeting" ? "Mobi-Meeting" : v === "zoom-meeting" ? "Zoom Meeting" : prev.customPlatformVenue || ""
                }))}
              >
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="mobi-meeting">Mobi-Meeting</SelectItem>
                  <SelectItem value="zoom-meeting">Zoom Meeting</SelectItem>
                  <SelectItem value="other">Other - Specify</SelectItem>
                </SelectContent>
              </Select>
              {formData.platformVenue === "other" && (
                <Input 
                  value={formData.customPlatformVenue || ""} 
                  onChange={(e) => setFormData(prev => ({ 
                    ...prev, 
                    customPlatformVenue: e.target.value,
                    venue: e.target.value
                  }))}
                  placeholder="Enter platform or venue name..."
                  className="mt-2 text-base"
                  style={{ touchAction: 'manipulation' }}
                  onClick={(e) => e.stopPropagation()}
                  autoComplete="off"
                />
              )}
            </div>
            {/* Conditional Address Field - Only for Indoor or Outdoor */}
            {(formData.venueType === "indoor" || formData.venueType === "outdoor") && (
              <div className="space-y-2">
                <Label>Venue Address</Label>
                <Input 
                  value={formData.venueAddress || ""} 
                  onChange={(e) => setFormData(prev => ({ ...prev, venueAddress: e.target.value }))}
                  placeholder="Enter venue address..."
                  className="text-base"
                  style={{ touchAction: 'manipulation' }}
                  onClick={(e) => e.stopPropagation()}
                  autoComplete="off"
                />
              </div>
            )}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-2">
                <Label>Start Date & Time</Label>
                <Input 
                  type="datetime-local" 
                  onChange={(e) => setFormData(prev => ({ ...prev, eventDate: new Date(e.target.value) }))}
                  className="text-base"
                  style={{ touchAction: 'manipulation' }}
                  onClick={(e) => e.stopPropagation()}
                />
              </div>
              <div className="space-y-2">
                <Label>End Date & Time</Label>
                <Input 
                  type="datetime-local" 
                  onChange={(e) => setFormData(prev => ({ ...prev, eventEndDate: new Date(e.target.value) }))}
                  className="text-base"
                  style={{ touchAction: 'manipulation' }}
                  onClick={(e) => e.stopPropagation()}
                />
              </div>
            </div>
            <div className="space-y-2">
              <Label>Capacity (optional)</Label>
              <Input 
                type="number" 
                value={formData.capacity || ""} 
                onChange={(e) => setFormData(prev => ({ ...prev, capacity: parseInt(e.target.value) || undefined }))}
                placeholder="Maximum attendees"
                className="text-base"
                style={{ touchAction: 'manipulation' }}
                onClick={(e) => e.stopPropagation()}
                autoComplete="off"
              />
            </div>
          </>
        );

      case "article":
        return (
          <>
            <div className="space-y-2">
              <Label>Category</Label>
              <Select 
                value={showCustomCategory ? "other" : (formData.category || "")} 
                onValueChange={(v) => {
                  if (v === "other") {
                    setShowCustomCategory(true);
                  } else {
                    setShowCustomCategory(false);
                    setCustomCategory("");
                    setFormData(prev => ({ ...prev, category: v }));
                  }
                }}
              >
                <SelectTrigger><SelectValue placeholder="Select category" /></SelectTrigger>
                <SelectContent>
                  {articleCategories.map(cat => (
                    <SelectItem key={cat} value={cat.toLowerCase()}>{cat}</SelectItem>
                  ))}
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
              {showCustomCategory && (
                <Input
                  placeholder="Enter custom category..."
                  value={customCategory}
                  onChange={(e) => {
                    setCustomCategory(e.target.value);
                    setFormData(prev => ({ ...prev, category: e.target.value.toLowerCase() }));
                  }}
                  className="mt-2 text-base"
                  style={{ touchAction: 'manipulation' }}
                  onClick={(e) => e.stopPropagation()}
                  autoComplete="off"
                />
              )}
            </div>
            <div className="space-y-2">
              <Label>Excerpt</Label>
              <Textarea 
                value={formData.description || ""} 
                onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                placeholder="Brief summary of the article"
                rows={2}
                className="text-base resize-none"
                style={{ touchAction: 'manipulation' }}
                onClick={(e) => e.stopPropagation()}
              />
            </div>
            <div className="space-y-2">
              <Label>Full Content</Label>
              <Textarea 
                value={formData.content || ""} 
                onChange={(e) => setFormData(prev => ({ ...prev, content: e.target.value }))}
                placeholder="Article content..."
                rows={6}
                className="text-base resize-none"
                style={{ touchAction: 'manipulation' }}
                onClick={(e) => e.stopPropagation()}
              />
            </div>
            <div className="space-y-2">
              <Label>Tags</Label>
              <div className="flex gap-2">
                <Input 
                  value={newTag} 
                  onChange={(e) => setNewTag(e.target.value)}
                  placeholder="Add tag"
                  onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addTag())}
                  className="text-base"
                  style={{ touchAction: 'manipulation' }}
                  onClick={(e) => e.stopPropagation()}
                  autoComplete="off"
                />
                <Button type="button" size="icon" variant="outline" onClick={addTag}>
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
              {formData.tags && formData.tags.length > 0 && (
                <div className="flex flex-wrap gap-1 mt-2">
                  {formData.tags.map(tag => (
                    <Badge key={tag} variant="secondary" className="gap-1">
                      {tag}
                      <button onClick={() => removeTag(tag)} className="ml-1">
                        <X className="h-3 w-3" />
                      </button>
                    </Badge>
                  ))}
                </div>
              )}
            </div>
            <div className="flex items-center justify-between">
              <Label>Featured Article</Label>
              <Switch checked={formData.featured} onCheckedChange={(v) => setFormData(prev => ({ ...prev, featured: v }))} />
            </div>
          </>
        );

      case "vibe":
        return (
          <>
            <div className="space-y-2">
              <Label>Media Type</Label>
              <div className="grid grid-cols-4 gap-2">
                {mediaTypes.map(type => {
                  const icons = { video: Video, photo: ImageIcon, audio: Music, gallery: Images };
                  const Icon = icons[type];
                  return (
                    <Button
                      key={type}
                      type="button"
                      variant={formData.mediaType === type ? "default" : "outline"}
                      className="flex flex-col h-16 gap-1"
                      onClick={() => setFormData(prev => ({ ...prev, mediaType: type }))}
                    >
                      <Icon className="h-5 w-5" />
                      <span className="text-[10px] capitalize">{type}</span>
                    </Button>
                  );
                })}
              </div>
            </div>
            {(formData.mediaType === "video" || formData.mediaType === "audio") && (
              <div className="space-y-2">
                <Label>Duration</Label>
                <Input 
                  value={formData.duration || ""} 
                  onChange={(e) => setFormData(prev => ({ ...prev, duration: e.target.value }))}
                  placeholder="e.g., 3:45"
                  className="text-base"
                  style={{ touchAction: 'manipulation' }}
                  onClick={(e) => e.stopPropagation()}
                  autoComplete="off"
                />
              </div>
            )}
            <div className="flex items-center justify-between">
              <Label>Add to Spotlight</Label>
              <Switch checked={formData.spotlight} onCheckedChange={(v) => setFormData(prev => ({ ...prev, spotlight: v }))} />
            </div>
          </>
        );

      default:
        return null;
    }
  };

  return (
    <Drawer open={open} onOpenChange={onOpenChange}>
      <DrawerContent className="max-h-[90vh]">
        <DrawerHeader className="border-b pb-4">
          <DrawerTitle>
            {editingItem ? `Edit ${contentTypeLabels[contentType]}` : `Create ${contentTypeLabels[contentType]}`}
          </DrawerTitle>
        </DrawerHeader>
        
        <ScrollArea className="flex-1 px-4 py-4 overflow-y-auto touch-auto" style={{ maxHeight: "60vh" }}>
          <div className="space-y-4">
            {/* Title - Common to all */}
            <div className="space-y-2">
              <Label>Title *</Label>
              <Input 
                value={formData.title || ""} 
                onChange={(e) => setFormData(prev => ({ ...prev, title: e.target.value }))}
                placeholder={`Enter ${contentType} title`}
                className="text-base"
                style={{ touchAction: 'manipulation' }}
                onClick={(e) => e.stopPropagation()}
                autoComplete="off"
              />
            </div>

            {/* Full Content - Common to most */}
            {contentType !== "article" && (
              <div className="space-y-2">
                <Label>{contentType === "vibe" ? "Caption" : "Full Content"}</Label>
              <Textarea 
                  value={formData.description || ""} 
                  onChange={(e) => setFormData(prev => ({ ...prev, description: e.target.value }))}
                  placeholder={contentType === "vibe" ? "Write a caption..." : "Enter full content..."}
                  rows={3}
                  className="text-base resize-none"
                  style={{ touchAction: 'manipulation' }}
                  onClick={(e) => e.stopPropagation()}
                />
              </div>
            )}

            {/* Thumbnail / Media Upload */}
            <div className="space-y-2">
              <Label>{contentType === "vibe" ? "Media Upload" : "Thumbnail"}</Label>
              <ImageUpload
                value={formData.thumbnail || ""}
                onChange={(value) => setFormData(prev => ({ 
                  ...prev, 
                  thumbnail: Array.isArray(value) ? value[0] : value 
                }))}
                mediaType={contentType === "vibe" 
                  ? (formData.mediaType === "video" ? "video" 
                    : formData.mediaType === "audio" ? "audio" 
                    : formData.mediaType === "gallery" ? "any" 
                    : "image")
                  : "image"
                }
                multiple={contentType === "vibe" && formData.mediaType === "gallery"}
                maxFiles={contentType === "vibe" && formData.mediaType === "gallery" ? 10 : 1}
                maxSize={contentType === "vibe" && formData.mediaType === "video" ? 50 : 10}
                aspectRatio={contentType === "vibe" ? "video" : "banner"}
                label={contentType === "vibe" 
                  ? `Upload ${formData.mediaType === "gallery" ? "Photos" : formData.mediaType || "Media"}`
                  : "Upload Thumbnail"
                }
                helperText={
                  contentType === "vibe" && formData.mediaType === "video"
                    ? "MP4, WebM up to 50MB"
                    : contentType === "vibe" && formData.mediaType === "audio"
                    ? "MP3, WAV up to 10MB"
                    : "PNG, JPG, GIF up to 10MB"
                }
              />
            </div>

            {/* Type-specific fields */}
            {renderTypeSpecificFields()}

            {/* Publish Option */}
            <div className="space-y-2">
              <Label>Publish Option</Label>
              <Select value={publishOption} onValueChange={(v) => setPublishOption(v as typeof publishOption)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="draft">Save as Draft</SelectItem>
                  <SelectItem value="pending">Submit for Review</SelectItem>
                  <SelectItem value="published">Publish Now</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </ScrollArea>

        <DrawerFooter className="border-t pt-4">
          <div className="flex gap-2 w-full">
            <DrawerClose asChild>
              <Button variant="outline" className="flex-1">Cancel</Button>
            </DrawerClose>
            <Button 
              className="flex-1 bg-purple-600 hover:bg-purple-700" 
              onClick={handleSubmit}
              disabled={!formData.title?.trim()}
            >
              {editingItem ? "Update" : "Create"}
            </Button>
          </div>
        </DrawerFooter>
      </DrawerContent>
    </Drawer>
  );
}
