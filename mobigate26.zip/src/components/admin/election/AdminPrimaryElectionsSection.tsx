import { useState, useEffect, useCallback } from "react";
import { 
  Vote, 
  Users, 
  Calendar, 
  Clock, 
  CheckCircle2, 
  PlayCircle,
  PauseCircle,
  ChevronRight,
  Trophy,
  BarChart3,
  Settings,
  Plus,
  Info,
  Star,
  ListChecks
} from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Avatar, AvatarImage, AvatarFallback } from "@/components/ui/avatar";
import { Progress } from "@/components/ui/progress";
import { ScrollArea } from "@/components/ui/scroll-area";
import { 
  Sheet,
  SheetContent,
  SheetHeader,
  SheetTitle,
} from "@/components/ui/sheet";
import { useToast } from "@/hooks/use-toast";
import { format } from "date-fns";
import { 
  mockElectionProcessSettings
} from "@/data/electionProcessesData";
import { PrimaryElection, PrimaryCandidate } from "@/types/electionProcesses";
import { cn } from "@/lib/utils";
import { CandidateVotersListSheet } from "./CandidateVotersListSheet";
import { SchedulePrimaryDrawer } from "./SchedulePrimaryDrawer";
import { MemberPreviewDialog } from "@/components/community/MemberPreviewDialog";
import { ExecutiveMember } from "@/data/communityExecutivesData";
import { 
  calculateAdvancingCandidates, 
  getAdvancementStatusText,
  AdvancementReason,
  DEFAULT_ADVANCEMENT_CONFIG
} from "@/lib/primaryElectionUtils";

const getStatusBadge = (status: PrimaryElection['status']) => {
  switch (status) {
    case 'completed':
      return <Badge className="bg-emerald-500 text-white text-xs">Completed</Badge>;
    case 'ongoing':
      return <Badge className="bg-blue-500 text-white text-xs">Ongoing</Badge>;
    case 'scheduled':
      return <Badge className="bg-amber-500 text-white text-xs">Scheduled</Badge>;
    case 'cancelled':
      return <Badge className="bg-red-500 text-white text-xs">Cancelled</Badge>;
    default:
      return null;
  }
};

interface StatCardProps {
  icon: React.ReactNode;
  value: number;
  label: string;
  color: string;
}

const StatCard = ({ icon, value, label, color }: StatCardProps) => (
  <div className={cn("flex flex-col items-center justify-center p-2 rounded-lg", color)}>
    <div className="flex items-center gap-1">
      {icon}
      <span className="text-lg font-bold">{value}</span>
    </div>
    <span className="text-xs text-muted-foreground">{label}</span>
  </div>
);

export function AdminPrimaryElectionsSection({ communityId }: { communityId?: string } = {}) {
  const { toast } = useToast();
  const [selectedPrimary, setSelectedPrimary] = useState<PrimaryElection | null>(null);
  const [showDetailSheet, setShowDetailSheet] = useState(false);
  const [showScheduleDrawer, setShowScheduleDrawer] = useState(false);
  const [mockPrimaryElections, setMockPrimaryElections] = useState<PrimaryElection[]>([]);
  const [primaryElectionId, setPrimaryElectionId] = useState<string | null>(null);
  const [concluding, setConcluding] = useState(false);

  const loadData = useCallback(() => {
    if (!communityId) return;
    fetch(`/api/community/elections.php?community_id=${communityId}`, { credentials: "include" })
      .then((r) => r.json())
      .then((d) => {
        const currentElection = (d.elections ?? []).find((e: any) => e.status === "primary")
          ?? (d.elections ?? []).find((e: any) => !['completed', 'cancelled'].includes(e.status));
        setPrimaryElectionId(currentElection?.id ?? null);
        if (!currentElection) { setMockPrimaryElections([]); return; }

        const officesForElection = (d.offices ?? []).filter((o: any) => o.election_id === currentElection.id);
        const mapped: PrimaryElection[] = officesForElection.map((o: any) => {
          const candidates = (d.candidates ?? []).filter((c: any) => c.office_id === o.id && c.status !== 'disqualified');
          const totalVotes = candidates.reduce((s: number, c: any) => s + (parseInt(c.primary_votes, 10) || 0), 0);
          return {
            id: o.id, officeId: o.id, officeName: o.name,
            scheduledDate: new Date(currentElection.primary_date || currentElection.created_at),
            startTime: "09:00", endTime: "18:00",
            status: (currentElection.status === "primary" ? "ongoing" : "completed") as any,
            candidates: candidates.map((c: any) => ({
              id: c.id, name: c.name?.trim() || "Candidate", avatar: c.profile_photo || "/placeholder.svg",
              votes: parseInt(c.primary_votes, 10) || 0,
              percentage: totalVotes > 0 ? ((parseInt(c.primary_votes, 10) || 0) / totalVotes) * 100 : 0,
              advancedToMain: c.status === "cleared", autoQualified: false,
            })),
            totalVotesCast: totalVotes, totalEligibleVoters: d.stats?.accredited ?? 0, winnerThreshold: 25,
          };
        }).filter((p: PrimaryElection) => p.candidates.length > 0);
        setMockPrimaryElections(mapped);
      })
      .catch(() => setMockPrimaryElections([]));
  }, [communityId]);

  useEffect(() => { loadData(); }, [loadData]);

  const handleConcludePrimary = async () => {
    if (!communityId || !primaryElectionId) return;
    setConcluding(true);
    try {
      const res = await fetch("/api/community/elections.php", {
        method: "POST", credentials: "include",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "conclude_primary", community_id: communityId, election_id: primaryElectionId, advance_count: 2 }),
      });
      const d = await res.json().catch(() => ({}));
      if (!res.ok) throw new Error(d.error || "Failed to conclude primary");
      toast({ title: "Primary Round Concluded", description: "Top candidates per office have advanced to the campaign stage." });
      setShowDetailSheet(false);
      loadData();
    } catch (e: any) {
      toast({ title: "Couldn't Conclude Primary", description: e.message, variant: "destructive" });
    } finally {
      setConcluding(false);
    }
  };
  
  // Voters List Sheet state
  const [votersListOpen, setVotersListOpen] = useState(false);
  const [selectedCandidate, setSelectedCandidate] = useState<{
    id: string;
    name: string;
    avatar: string;
    votes: number;
    isWinner: boolean;
    officeName: string;
  } | null>(null);

  // Member Preview state
  const [selectedMember, setSelectedMember] = useState<ExecutiveMember | null>(null);
  const [showMemberPreview, setShowMemberPreview] = useState(false);

  const openVotersList = (candidate: typeof selectedCandidate, officeName: string) => {
    if (candidate) {
      setSelectedCandidate({ ...candidate, officeName });
      setVotersListOpen(true);
    }
  };

  const handleCandidateClick = (candidate: { id: string; name: string; avatar?: string }) => {
    setSelectedMember({
      id: candidate.id,
      name: candidate.name,
      position: "Community Member",
      tenure: "",
      imageUrl: candidate.avatar || "/placeholder.svg",
      level: "officer",
      committee: "executive",
    });
    setShowMemberPreview(true);
  };

  const stats = {
    total: mockPrimaryElections.length,
    completed: mockPrimaryElections.filter((p) => p.status === "completed").length,
    scheduled: mockPrimaryElections.filter((p) => p.status === "scheduled" || p.status === "ongoing").length,
  };

  const handleStartPrimary = (primary: PrimaryElection) => {
    toast({
      title: "Primary Election Started",
      description: `Primary for ${primary.officeName} is now active`,
    });
  };

  const handleEndPrimary = (primary: PrimaryElection) => {
    toast({
      title: "Primary Election Ended",
      description: `Primary for ${primary.officeName} has been completed`,
    });
  };

  const openPrimaryDetail = (primary: PrimaryElection) => {
    setSelectedPrimary(primary);
    setShowDetailSheet(true);
  };

  return (
    <div className="space-y-4 pb-20">
      {/* Stats Row */}
      <div className="grid grid-cols-3 gap-2">
        <StatCard 
          icon={<Vote className="h-3.5 w-3.5 text-blue-600" />} 
          value={stats.total} 
          label="Total" 
          color="bg-blue-500/10" 
        />
        <StatCard 
          icon={<CheckCircle2 className="h-3.5 w-3.5 text-emerald-600" />} 
          value={stats.completed} 
          label="Completed" 
          color="bg-emerald-500/10" 
        />
        <StatCard 
          icon={<Clock className="h-3.5 w-3.5 text-amber-600" />} 
          value={stats.scheduled} 
          label="Scheduled" 
          color="bg-amber-500/10" 
        />
      </div>

      {primaryElectionId && mockPrimaryElections.length > 0 && (
        <Button className="w-full" disabled={concluding} onClick={handleConcludePrimary}>
          {concluding ? "Concluding..." : "Conclude Primary Round — Advance Top 2 Per Office"}
        </Button>
      )}

      {/* Action Button */}
      <Button 
        className="w-full bg-green-600 hover:bg-green-700 gap-2"
        onClick={() => setShowScheduleDrawer(true)}
      >
        <Plus className="h-4 w-4" />
        Schedule New Primary
      </Button>

      {/* Primary Elections List */}
      <div className="space-y-3">
        {mockPrimaryElections.map((primary) => (
          <Card 
            key={primary.id} 
            className="overflow-hidden cursor-pointer active:scale-[0.99] transition-transform"
            onClick={() => openPrimaryDetail(primary)}
          >
            <CardContent className="p-2.5">
              {/* Header */}
              <div className="flex items-start justify-between mb-2">
                <div>
                  <h4 className="font-semibold text-sm">{primary.officeName}</h4>
                  <div className="flex flex-col gap-0.5 mt-0.5">
                    <p className="text-xs text-muted-foreground flex items-center gap-1">
                      <Calendar className="h-3 w-3 shrink-0" />
                      {format(primary.scheduledDate, "MMM d, yyyy")}
                    </p>
                    <p className="text-xs text-muted-foreground flex items-center gap-1">
                      <Clock className="h-3 w-3 shrink-0" />
                      {primary.startTime} - {primary.endTime}
                    </p>
                  </div>
                </div>
                {getStatusBadge(primary.status)}
              </div>

              {/* Stats */}
              {primary.status !== 'scheduled' && (
                <div className="bg-muted/50 rounded-lg p-2.5 mb-2">
                  <div className="flex justify-between text-xs mb-1.5">
                    <span className="text-muted-foreground">Voter Turnout</span>
                    <span className="font-medium">
                      {Math.round((primary.totalVotesCast / primary.totalEligibleVoters) * 100)}%
                    </span>
                  </div>
                  <Progress 
                    value={(primary.totalVotesCast / primary.totalEligibleVoters) * 100} 
                    className="h-1.5"
                  />
                    <div className="flex justify-between text-xs text-muted-foreground mt-1">
                    <span>{primary.totalVotesCast} votes</span>
                    <span>{primary.totalEligibleVoters} eligible</span>
                  </div>
                </div>
              )}

            {/* Candidates Preview */}
              {primary.candidates.length > 0 && (() => {
                const config = {
                  autoQualifyThreshold: mockElectionProcessSettings.primaryAdvancementThreshold,
                  minimumAdvancing: mockElectionProcessSettings.primaryAdvancementMinimum,
                  maximumAdvancing: mockElectionProcessSettings.primaryAdvancementMaximum,
                };
                const advancementResult = calculateAdvancingCandidates(primary.candidates, config);
                
                return (
                  <div className="space-y-1.5">
                    {primary.candidates.slice(0, 2).map((candidate, idx) => {
                      const reason = advancementResult.advancementReasons.get(candidate.id);
                      const isAutoQualified = reason === 'auto_qualified';
                      const isTopVotes = reason === 'top_votes';
                      const advances = isAutoQualified || isTopVotes;
                      
                      return (
                        <div 
                          key={candidate.id}
                          className={cn(
                            "p-2 rounded-lg",
                            isAutoQualified ? "bg-emerald-50 dark:bg-emerald-950/20" : 
                            isTopVotes ? "bg-amber-50 dark:bg-amber-950/20" : 
                            "bg-muted/30"
                          )}
                        >
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-medium text-muted-foreground w-4 shrink-0">
                              {idx + 1}.
                            </span>
                            <Avatar className="h-6 w-6 shrink-0">
                              <AvatarImage src={candidate.avatar} />
                              <AvatarFallback className="text-xs">{candidate.name[0]}</AvatarFallback>
                            </Avatar>
                            <div className="flex-1 min-w-0">
                              <div className="flex items-center gap-1">
                                <span className="text-xs font-medium truncate">
                                  {candidate.name}
                                </span>
                                {isAutoQualified && (
                                  <Star className="h-3 w-3 text-emerald-500 fill-emerald-500 shrink-0" />
                                )}
                                {isTopVotes && (
                                  <Trophy className="h-3 w-3 text-amber-500 shrink-0" />
                                )}
                              </div>
                              <div className="flex items-center gap-1.5 mt-0.5">
                                <span className="text-xs font-bold">{candidate.percentage}%</span>
                                <span className="text-xs text-muted-foreground">· {candidate.votes} votes</span>
                              </div>
                            </div>
                          </div>
                        </div>
                      );
                    })}
                    {primary.candidates.length > 2 && (
                      <p className="text-xs text-muted-foreground text-center">
                        +{primary.candidates.length - 2} more candidates
                      </p>
                    )}
                  </div>
                );
              })()}

              {primary.status === 'scheduled' && (
                <div className="flex items-center justify-center gap-2 text-xs text-muted-foreground p-4 bg-muted/30 rounded-lg">
                  <Clock className="h-4 w-4" />
                  Candidates will be shown after screening
                </div>
              )}

              {/* View Details */}
              <div className="flex items-center justify-center gap-1 text-xs text-primary mt-2 pt-2 border-t">
                <span>View Details</span>
                <ChevronRight className="h-3 w-3" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Primary Election Detail Sheet - Mobile optimized */}
      <Sheet open={showDetailSheet} onOpenChange={setShowDetailSheet}>
        <SheetContent side="bottom" className="h-[92vh] rounded-t-2xl p-0 flex flex-col">
          <SheetHeader className="px-3 pt-4 pb-3 border-b shrink-0">
            <SheetTitle className="flex items-center gap-2">
              <Vote className="h-5 w-5 text-primary" />
              Primary Election Details
            </SheetTitle>
          </SheetHeader>

          {selectedPrimary && (
            <ScrollArea className="flex-1 overflow-y-auto touch-auto">
              <div className="space-y-3 px-2 py-3">
                {/* Election Info - Compact card */}
                <div className="p-2.5 rounded-lg border bg-card space-y-3">
                  <div className="flex items-start justify-between gap-2">
                    <div className="min-w-0 flex-1">
                      <h3 className="font-bold text-sm leading-tight">{selectedPrimary.officeName}</h3>
                      <p className="text-xs text-muted-foreground">Primary Election</p>
                    </div>
                    {getStatusBadge(selectedPrimary.status)}
                  </div>
                  
                  {/* Date & Time - Side by side */}
                  <div className="flex gap-2">
                    <div className="flex items-center gap-2 flex-1 p-2 bg-muted/50 rounded-lg">
                      <Calendar className="h-4 w-4 text-muted-foreground shrink-0" />
                      <div className="min-w-0">
                        <p className="text-xs text-muted-foreground leading-tight">Date</p>
                        <p className="font-medium text-xs">{format(selectedPrimary.scheduledDate, "MMM d, yyyy")}</p>
                      </div>
                    </div>
                    <div className="flex items-center gap-2 flex-1 p-2 bg-muted/50 rounded-lg">
                      <Clock className="h-4 w-4 text-muted-foreground shrink-0" />
                      <div className="min-w-0">
                        <p className="text-xs text-muted-foreground leading-tight">Time</p>
                        <p className="font-medium text-xs">{selectedPrimary.startTime} - {selectedPrimary.endTime}</p>
                      </div>
                    </div>
                  </div>
                </div>

                {/* Turnout Stats - Compact */}
                {selectedPrimary.status !== 'scheduled' && (
                  <div className="p-2.5 rounded-lg border bg-card space-y-2">
                    <div className="flex items-center gap-2">
                      <BarChart3 className="h-4 w-4 text-primary shrink-0" />
                      <span className="text-sm font-semibold">Voter Turnout</span>
                    </div>
                    
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Total Votes Cast</span>
                      <span className="font-bold">{selectedPrimary.totalVotesCast.toLocaleString()}</span>
                    </div>
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Eligible Voters</span>
                      <span className="font-medium">{selectedPrimary.totalEligibleVoters.toLocaleString()}</span>
                    </div>
                    <Progress 
                      value={(selectedPrimary.totalVotesCast / selectedPrimary.totalEligibleVoters) * 100} 
                      className="h-2"
                    />
                    <p className="text-center text-sm font-bold text-primary">
                      {Math.round((selectedPrimary.totalVotesCast / selectedPrimary.totalEligibleVoters) * 100)}% Turnout
                    </p>
                  </div>
                )}

              {/* Advancement Rules Info - Compact list */}
                {selectedPrimary.candidates.length > 0 && (
                  <div className="p-2.5 rounded-lg bg-blue-500/5 border border-blue-500/20">
                    <div className="flex items-start gap-2">
                      <Info className="h-4 w-4 text-blue-600 mt-0.5 shrink-0" />
                      <div className="text-xs space-y-1 min-w-0">
                        <p className="font-semibold text-blue-700 dark:text-blue-400">Advancement Rules</p>
                        <ul className="text-muted-foreground space-y-0.5">
                          <li className="flex items-center gap-1.5">
                            <Star className="h-3 w-3 text-emerald-500 fill-emerald-500 shrink-0" />
                            <span>≥25% votes = Auto-qualifies</span>
                          </li>
                          <li className="flex items-center gap-1.5">
                            <Trophy className="h-3 w-3 text-amber-500 shrink-0" />
                            <span>Top votes fill remaining slots</span>
                          </li>
                          <li>• Maximum 4 candidates advance</li>
                          <li>• Minimum 2 candidates required</li>
                        </ul>
                      </div>
                    </div>
                  </div>
                )}

                {/* Candidates Results - Clean list */}
                {selectedPrimary.candidates.length > 0 && (() => {
                  const config = {
                    autoQualifyThreshold: mockElectionProcessSettings.primaryAdvancementThreshold,
                    minimumAdvancing: mockElectionProcessSettings.primaryAdvancementMinimum,
                    maximumAdvancing: mockElectionProcessSettings.primaryAdvancementMaximum,
                  };
                  const advancementResult = calculateAdvancingCandidates(selectedPrimary.candidates, config);
                  
                  return (
                    <div className="space-y-2.5">
                      <div className="flex items-center justify-between px-1">
                        <div className="flex items-center gap-2">
                          <Users className="h-4 w-4 text-primary shrink-0" />
                          <span className="text-sm font-semibold">Candidates Results</span>
                        </div>
                        <Badge variant="secondary" className="text-xs">
                          {advancementResult.totalAdvancing} advancing
                        </Badge>
                      </div>
                      
                      {advancementResult.autoQualifiedCount > 0 && (
                        <p className="text-xs text-muted-foreground px-1">
                          {advancementResult.autoQualifiedCount} auto-qualified (≥25%)
                          {advancementResult.topVoteFilledCount > 0 && 
                            ` • ${advancementResult.topVoteFilledCount} by top votes`
                          }
                        </p>
                      )}
                      
                      <div className="space-y-2">
                        {selectedPrimary.candidates.map((candidate, idx) => {
                          const reason = advancementResult.advancementReasons.get(candidate.id);
                          const isAutoQualified = reason === 'auto_qualified';
                          const isTopVotes = reason === 'top_votes';
                          const advances = isAutoQualified || isTopVotes;
                            
                            return (
                              <div 
                                key={candidate.id}
                                className={cn(
                                  "p-2.5 rounded-lg border",
                                  isAutoQualified 
                                    ? "bg-emerald-50 dark:bg-emerald-950/20 border-emerald-200 dark:border-emerald-800" 
                                    : isTopVotes
                                    ? "bg-amber-50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-800"
                                    : "bg-muted/30 border-transparent"
                                )}
                              >
                                <div 
                                  className="flex items-center gap-2.5 mb-2 cursor-pointer active:opacity-70 transition-opacity"
                                  onClick={(e) => {
                                    e.stopPropagation();
                                    handleCandidateClick(candidate);
                                  }}
                                >
                                  <span className="text-sm font-bold text-muted-foreground w-4">
                                    {idx + 1}.
                                  </span>
                                  <Avatar className="h-9 w-9">
                                    <AvatarImage src={candidate.avatar} />
                                    <AvatarFallback>{candidate.name[0]}</AvatarFallback>
                                  </Avatar>
                                  <div className="flex-1 min-w-0">
                                    <p className="font-semibold text-sm">{candidate.name}</p>
                                    {isAutoQualified && (
                                      <Badge className="bg-emerald-500 text-white text-xs mt-0.5">
                                        <Star className="h-2.5 w-2.5 mr-1 fill-white" />
                                        Auto-Qualified ({candidate.percentage}%)
                                      </Badge>
                                    )}
                                    {isTopVotes && (
                                      <Badge className="bg-amber-500 text-white text-xs mt-0.5">
                                        <Trophy className="h-2.5 w-2.5 mr-1" />
                                        Advances (Top Votes)
                                      </Badge>
                                    )}
                                  </div>
                                </div>
                                <div className="ml-7">
                                  <div className="flex justify-between text-xs mb-1">
                                    <span className="text-muted-foreground">{candidate.votes.toLocaleString()} votes</span>
                                    <span className="font-bold">{candidate.percentage}%</span>
                                  </div>
                                  {/* Progress bar with 25% threshold marker */}
                                  <div className="relative">
                                    <Progress 
                                      value={candidate.percentage} 
                                      className={cn(
                                        "h-2",
                                        isAutoQualified && "[&>div]:bg-emerald-500",
                                        isTopVotes && "[&>div]:bg-amber-500"
                                      )}
                                    />
                                    {/* 25% threshold line */}
                                    <div 
                                      className="absolute top-0 bottom-0 w-0.5 bg-red-500/60"
                                      style={{ left: '25%' }}
                                    />
                                  </div>
                                  <div className="flex justify-between text-xs text-muted-foreground mt-0.5">
                                    <span></span>
                                    <span className="text-red-500/80">25% threshold ↑</span>
                                  </div>
                                  
                                  {/* Voters List Button */}
                                  <Button
                                    variant="outline"
                                    size="sm"
                                    className="w-full mt-2 h-7 text-xs gap-1.5"
                                    onClick={() => openVotersList({
                                      id: candidate.id,
                                      name: candidate.name,
                                      avatar: candidate.avatar,
                                      votes: candidate.votes,
                                      isWinner: advances,
                                      officeName: selectedPrimary.officeName
                                    }, selectedPrimary.officeName)}
                                  >
                                    <ListChecks className="h-3.5 w-3.5" />
                                    Voters List
                                  </Button>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      </div>
                  );
                })()}

                {/* Actions */}
                {selectedPrimary.status === 'scheduled' && (
                  <div className="flex gap-2 pt-2">
                    <Button 
                      className="flex-1 bg-green-600 hover:bg-green-700"
                      onClick={() => handleStartPrimary(selectedPrimary)}
                    >
                      <PlayCircle className="h-4 w-4 mr-2" />
                      Start Election
                    </Button>
                  </div>
                )}

                {selectedPrimary.status === 'ongoing' && (
                  <div className="flex gap-2 pt-2">
                    <Button 
                      variant="outline"
                      className="flex-1"
                    >
                      <Settings className="h-4 w-4 mr-2" />
                      Manage
                    </Button>
                    <Button 
                      className="flex-1 bg-red-600 hover:bg-red-700"
                      onClick={() => handleEndPrimary(selectedPrimary)}
                    >
                      <PauseCircle className="h-4 w-4 mr-2" />
                      End Election
                    </Button>
                  </div>
                )}
              </div>
            </ScrollArea>
          )}
        </SheetContent>
      </Sheet>

      {/* Candidate Voters List Sheet */}
      {selectedCandidate && (
        <CandidateVotersListSheet
          open={votersListOpen}
          onOpenChange={setVotersListOpen}
          candidateId={selectedCandidate.id}
          candidateName={selectedCandidate.name}
          candidateAvatar={selectedCandidate.avatar}
          voteCount={selectedCandidate.votes}
          officeName={selectedCandidate.officeName}
          isWinner={selectedCandidate.isWinner}
        />
      )}

      {/* Schedule Primary Drawer */}
      <SchedulePrimaryDrawer
        open={showScheduleDrawer}
        onOpenChange={setShowScheduleDrawer}
        onScheduled={() => {
          toast({
            title: "Primary Scheduled",
            description: "The primary election has been scheduled successfully"
          });
          setShowScheduleDrawer(false);
        }}
      />

      {/* Member Preview Dialog */}
      <MemberPreviewDialog
        member={selectedMember}
        open={showMemberPreview}
        onOpenChange={setShowMemberPreview}
      />
    </div>
  );
}
