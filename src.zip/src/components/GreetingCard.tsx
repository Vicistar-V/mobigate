import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Search, MoreHorizontal, ChevronLeft, ChevronRight, ImagePlus, BadgeCheck, Images, Plus, Maximize2, PenSquare, FilePlus2, LayoutList } from "lucide-react";
import { Link, useNavigate } from "react-router-dom";
import { CreatePostDialog } from "./CreatePostDialog";
import { EditPostDialog } from "./EditPostDialog";
import {
  Dialog as ActionDialog,
  DialogContent as ActionDialogContent,
  DialogHeader as ActionDialogHeader,
  DialogTitle as ActionDialogTitle,
  DialogDescription as ActionDialogDescription,
} from "@/components/ui/dialog";
import { PeopleYouMayKnow } from "./PeopleYouMayKnow";
import { TopTrendingHeadlines } from "./TopTrendingHeadlines";
import { HeadlinesYouDontWannaMiss } from "./HeadlinesYouDontWannaMiss";
import { useServiceUnavailableDialog } from "@/hooks/useServiceUnavailableDialog";
import { useState, useEffect, useRef, useCallback } from "react";
import { ScrollableThumbStrip } from "@/components/feed/ScrollableThumbStrip";
import { FeedShowcaseDialog } from "@/components/feed/FeedShowcaseDialog";
import { UserTagBadges } from "./UserTagBadges";
import { useUserProfile, useCurrentUserId, useFeedPosts } from "@/hooks/useWindowData";
import { feedPosts as fallbackFeedPosts } from "@/data/posts";
import heroAdBanner from "@/assets/hero-ad-banner.jpg";
import { MediaGalleryViewer, MediaItem } from "@/components/MediaGalleryViewer";
import { WallBannerSlideshow } from "@/components/wall-banner/WallBannerSlideshow";
import { WallBannerManagerDialog } from "@/components/wall-banner/WallBannerManagerDialog";
import { getActiveSlidesFor } from "@/lib/wallBannerStorage";
import { PostDetailDialog } from "@/components/PostDetailDialog";

export const GreetingSection = ({
  profileUserId,
  editable,
  embed = false,
}: {
  /** The owner of the profile being viewed. Defaults to the current user (home/own profile). */
  profileUserId?: string;
  /** Whether posting/editing affordances are shown. Defaults to true only on the owner's own page. */
  editable?: boolean;
  /** When true, render ONLY the posting area (Stories / Vibes / Breaking News) — no hero, nav, or search. */
  embed?: boolean;
} = {}) => {
  const profile = useUserProfile();
  const navigate = useNavigate();
  const currentUserId = useCurrentUserId();
  // Whose posts power the "own" areas — the profile owner, not necessarily the viewer.
  const ownerId = profileUserId ?? currentUserId;
  // Editing is only allowed on your own page.
  const canEdit = editable ?? (ownerId === currentUserId);
  const phpFeedPosts = useFeedPosts();
  const allPosts = phpFeedPosts || fallbackFeedPosts;

  // Active posting-area tab — drives which slice of content is shown in place.
  const [activeFeedTab, setActiveFeedTab] = useState<"Stories" | "Vibes & Flexing" | "Breaking News">("Stories");

  // Per-tab metadata: contextual keywords used to surface relevant content,
  // and the label shown on the "see more" footer link.
  const TAB_META = {
    "Stories": {
      keywords: [] as string[],
      moreLabel: "Enjoy more exciting stories",
      composeCta: "Post & Share something now",
    },
    "Vibes & Flexing": {
      keywords: ["vibe", "flex", "fun", "party", "weekend", "lifestyle", "style"],
      moreLabel: "Flex with more exciting Vibes",
      composeCta: "Post & Share your Vibe now",
    },
    "Breaking News": {
      keywords: ["news", "breaking", "update", "alert", "report", "headline"],
      moreLabel: "Catch up on more Breaking News",
      composeCta: "Post & Share Breaking News now",
    },
  } as const;
  const tabMeta = TAB_META[activeFeedTab];

  const matchesTab = (p: typeof allPosts[number]) => {
    if (!tabMeta.keywords.length) return true;
    const hay = `${p.title || ""} ${(p as any).subtitle || ""} ${(p as any).description || ""} ${(p as any).label || ""} ${(p as any).category || ""}`.toLowerCase();
    return tabMeta.keywords.some((k) => hay.includes(k));
  };

  // The User's OWN most recent post — pinned to the TOP big image space (never changes via thumbs)
  const myOwnPostsAll = allPosts.filter((p) => p.userId === ownerId);
  const myOwnTabMatches = myOwnPostsAll.filter(matchesTab);
  // Keep the area populated even when a tab has no exact matches.
  const myOwnPosts = myOwnTabMatches.length > 0 ? myOwnTabMatches : myOwnPostsAll;
  const myLatestOwnPost = myOwnPosts[0] || allPosts[0];

  // Public/connection posts from OTHER users — drive the SECOND big image space
  const publicConnectionPosts = (() => {
    const others = allPosts.filter(
      (p) => p.userId !== ownerId && ((p as any).privacy ?? "Public") === "Public",
    );
    const tabbed = others.filter(matchesTab);
    // Surface tab-relevant posts first, but always keep the strip well-populated
    // by appending the remaining public posts behind them.
    const base =
      tabbed.length > 0
        ? [...tabbed, ...others.filter((o) => !tabbed.includes(o))]
        : others;
    // Fallback so the space is never empty
    return base.length > 0 ? base.slice(0, 16) : allPosts.filter((p) => p.userId !== ownerId).slice(0, 16);
  })();

  // Thumbnail strip — User's own + Public connection posts, de-duped
  const thumbnailPosts = (() => {
    const seen = new Set<string>();
    const out: typeof allPosts = [];
    for (const p of [...myOwnPosts, ...publicConnectionPosts]) {
      const key = p.id || p.imageUrl;
      if (seen.has(key)) continue;
      seen.add(key);
      out.push(p);
    }
    return out.slice(0, 16);
  })();

  // The SECOND big space rotates based on which thumbnail was tapped (any thumb, own or public)
  const [featuredPublicIdx, setFeaturedPublicIdx] = useState(0);
  const [viewerOpen, setViewerOpen] = useState(false);
  // Full-window "see all" showcase with Filter (applies to every feed area).
  const [showcaseOpen, setShowcaseOpen] = useState(false);
  const [viewerStartIndex, setViewerStartIndex] = useState(0);
  const [storyDetailOpen, setStoryDetailOpen] = useState(false);
  const [ownActionsOpen, setOwnActionsOpen] = useState(false);
  const [editPostOpen, setEditPostOpen] = useState(false);
  const [wallBannerManagerOpen, setWallBannerManagerOpen] = useState(false);
  const [bannerViewerOpen, setBannerViewerOpen] = useState(false);
  const [viewerItems, setViewerItems] = useState<MediaItem[]>([]);
  const safeFeaturedIdx = Math.min(featuredPublicIdx, Math.max(0, thumbnailPosts.length - 1));
  const featuredPublicPost = thumbnailPosts[safeFeaturedIdx] || thumbnailPosts[0] || myLatestOwnPost;

  // Keep the selected vibe thumbnail scrolled into view (e.g. when using ◄ / ► arrows)
  const vibeStripRef = useRef<HTMLDivElement>(null);
  useEffect(() => {
    const strip = vibeStripRef.current;
    if (!strip) return;
    const activeEl = strip.querySelector<HTMLElement>('[data-vibe-active="true"]');
    if (activeEl) {
      activeEl.scrollIntoView({ behavior: "smooth", inline: "center", block: "nearest" });
    }
  }, [safeFeaturedIdx]);

  // Real Play-style scroll arrows for the Vibes thumbnail strip: track which
  // direction still has hidden items so the arrows can dim when exhausted.
  const [vibeCanLeft, setVibeCanLeft] = useState(false);
  const [vibeCanRight, setVibeCanRight] = useState(false);
  const updateVibeScroll = useCallback(() => {
    const el = vibeStripRef.current;
    if (!el) return;
    const { scrollLeft, scrollWidth, clientWidth } = el;
    setVibeCanLeft(scrollLeft > 2);
    setVibeCanRight(scrollLeft + clientWidth < scrollWidth - 2);
  }, []);
  useEffect(() => {
    const el = vibeStripRef.current;
    if (!el) return;
    updateVibeScroll();
    el.addEventListener("scroll", updateVibeScroll, { passive: true });
    window.addEventListener("resize", updateVibeScroll);
    return () => {
      el.removeEventListener("scroll", updateVibeScroll);
      window.removeEventListener("resize", updateVibeScroll);
    };
  }, [updateVibeScroll, safeFeaturedIdx, activeFeedTab]);
  const scrollVibeStrip = (dir: "left" | "right") => {
    const el = vibeStripRef.current;
    if (!el) return;
    const amount = Math.max(el.clientWidth * 0.7, 120);
    el.scrollBy({ left: dir === "left" ? -amount : amount, behavior: "smooth" });
  };
  // Keep legacy names so the rest of the file keeps compiling unchanged
  const featuredPost = myLatestOwnPost;
  const myRecentPosts = thumbnailPosts;
  const setFeaturedIdx = setFeaturedPublicIdx;

  // ────────────────────────────────────────────────────────────────────────
  // VIBES & FLEXING data model
  //  • Area A  → the User's OWN posts (latest on display; rest via the + menu)
  //  • Area B  → everyone's posts (own + others), auto-scrolling. Ordering:
  //              Newest (last 7 days) first, then Most Trending (engagement).
  //  • "Flex with more exciting Vibes" → full window of ALL vibes by everybody.
  // ────────────────────────────────────────────────────────────────────────
  const [ownPostsViewerOpen, setOwnPostsViewerOpen] = useState(false);
  const [allVibesViewerOpen, setAllVibesViewerOpen] = useState(false);
  const [allVibesStartIdx, setAllVibesStartIdx] = useState(0);
  const [editPickerOpen, setEditPickerOpen] = useState(false);
  const [postToEdit, setPostToEdit] = useState<typeof allPosts[number] | null>(null);

  const scoreEngagement = (p: any) =>
    (Number(p.likes) || 0) +
    (Number(p.views) || 0) +
    (Number(p.comments) || 0) +
    (Number(p.shares) || 0) +
    (Number(p.followers) || 0);
  const postTime = (p: any) => {
    const t = Date.parse(p.timestamp || p.createdAt || p.date || "");
    return Number.isNaN(t) ? 0 : t;
  };
  const sortNewestThenTrending = (posts: typeof allPosts) => {
    const now = Date.now();
    const WEEK = 7 * 24 * 60 * 60 * 1000;
    const recent: typeof allPosts = [];
    const rest: typeof allPosts = [];
    posts.forEach((p) => {
      const t = postTime(p);
      if (t > 0 && now - t <= WEEK) recent.push(p);
      else rest.push(p);
    });
    recent.sort((a, b) => postTime(b) - postTime(a));
    rest.sort((a, b) => scoreEngagement(b) - scoreEngagement(a));
    return [...recent, ...rest];
  };

  // Area B — everyone's vibes (own + others), de-duped & ordered.
  const communityVibes = (() => {
    const tabbed = allPosts.filter(matchesTab);
    const base = tabbed.length > 1 ? tabbed : allPosts;
    const seen = new Set<string>();
    const uniq: typeof allPosts = [];
    for (const p of base) {
      const k = p.id || p.imageUrl;
      if (seen.has(k)) continue;
      seen.add(k);
      uniq.push(p);
    }
    return sortNewestThenTrending(uniq).slice(0, 24);
  })();

  // Map feed posts → MediaGalleryViewer items (shared by the own + all viewers).
  const toMediaItems = (posts: typeof allPosts): MediaItem[] =>
    posts.map((p, i) => ({
      id: p.id || `vibe-media-${i}`,
      url: p.imageUrl,
      type:
        (p as any).type?.toLowerCase() === "video"
          ? "video"
          : (p as any).type?.toLowerCase() === "audio"
          ? "audio"
          : "photo",
      title: p.title,
      author: (p as any).author,
      authorImage: (p as any).authorProfileImage,
      authorUserId: (p as any).userId,
      description: (p as any).description,
      timestamp: (p as any).timestamp,
      likes: Number((p as any).likes) || 0,
      comments: Number((p as any).comments) || 0,
      views: Number((p as any).views) || 0,
      followers: (p as any).followers,
      isOwner: (p as any).userId === currentUserId,
    }));

  // Every post belonging to the active feed area (own + connections + public),
  // de-duped — feeds the full-window "see all" showcase with its Filter menu.
  const showcaseMediaItems = (() => {
    const tabbed = allPosts.filter(matchesTab);
    const base = tabbed.length > 0 ? tabbed : allPosts;
    const seen = new Set<string>();
    const uniq: typeof allPosts = [];
    for (const p of base) {
      const k = p.id || p.imageUrl;
      if (seen.has(k)) continue;
      seen.add(k);
      uniq.push(p);
    }
    return toMediaItems(uniq);
  })();


  // Auto-scroll Area B horizontally (marquee), pausing briefly on interaction.
  useEffect(() => {
    if (activeFeedTab !== "Vibes & Flexing") return;
    const el = vibeStripRef.current;
    if (!el) return;
    let paused = false;
    let resumeT: ReturnType<typeof setTimeout>;
    const pause = () => {
      paused = true;
      clearTimeout(resumeT);
      resumeT = setTimeout(() => {
        paused = false;
      }, 2500);
    };
    el.addEventListener("pointerdown", pause, { passive: true });
    el.addEventListener("wheel", pause, { passive: true });
    const id = setInterval(() => {
      if (paused || !el) return;
      const atEnd = el.scrollLeft + el.clientWidth >= el.scrollWidth - 2;
      if (atEnd) el.scrollTo({ left: 0, behavior: "smooth" });
      else el.scrollBy({ left: 1 });
    }, 30);
    return () => {
      clearInterval(id);
      clearTimeout(resumeT);
      el.removeEventListener("pointerdown", pause);
      el.removeEventListener("wheel", pause);
    };
  }, [activeFeedTab, communityVibes.length]);

  const openAllVibes = (startIdx = 0) => {
    setAllVibesStartIdx(startIdx);
    setAllVibesViewerOpen(true);
  };

  // Tapping the owner's own media: on your own page → Edit/Create/View menu;
  // when viewing someone else's page → read-only viewer (no editing).
  const handleOwnPrimary = () => {
    if (canEdit) {
      setOwnActionsOpen(true);
    } else if (featuredPost) {
      setOwnPostsViewerOpen(true);
    }
  };








  const [friendsMenuView, setFriendsMenuView] = useState<"main" | "requests" | "birthdays">("main");
  const [createPostOpen, setCreatePostOpen] = useState(false);
  const [presetMediaUrl, setPresetMediaUrl] = useState<string | null>(null);
  const [presetTitle, setPresetTitle] = useState<string>("");
  const galleryInputRef = useRef<HTMLInputElement>(null);
  const { showDialog, Dialog } = useServiceUnavailableDialog();
  const restrictedServices = ["/mobi-shop", "/mobi-circle", "/biz-catalogue"];

  // Live ticking clock
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);
  const liveDate = now.toLocaleDateString(undefined, {
    weekday: "short",
    month: "short",
    day: "numeric",
  });
  const liveTime = now.toLocaleTimeString(undefined, {
    hour: "numeric",
    minute: "2-digit",
    hour12: true,
  });

  const openComposerWithImage = (url: string, title?: string) => {
    setPresetMediaUrl(url);
    setPresetTitle(title || "");
    setCreatePostOpen(true);
  };

  const openComposerBlank = () => {
    setPresetMediaUrl(null);
    setPresetTitle("");
    setCreatePostOpen(true);
  };

  const handleGalleryFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onloadend = () => {
      openComposerWithImage(reader.result as string);
    };
    reader.readAsDataURL(file);
    if (galleryInputRef.current) galleryInputRef.current.value = "";
  };

  const handleLinkClick = (e: React.MouseEvent, href: string, action?: string) => {
    if (action === "openChat") {
      e.preventDefault();
      const messagesButton = document.querySelector(
        "[data-messages-trigger]"
      ) as HTMLElement;
      messagesButton?.click();
      return;
    }
    if (restrictedServices.includes(href)) {
      e.preventDefault();
      showDialog();
    }
  };

  const primaryLinks = [{ label: "About", href: `/profile/${currentUserId}#about` }];
  const moreLinks = [
    { label: "Followers", href: `/profile/${currentUserId}#followers` },
    { label: "Following", href: `/profile/${currentUserId}#following` },
    { label: "Gifts", href: `/profile/${currentUserId}#gifts` },
    { label: "MobiChat", href: "#", action: "openChat" },
    { label: "Mobi Quiz Games", href: "/mobi-quiz-games" },
    { label: "Mobi-Store", href: "/mobi-shop" },
    { label: "Mobi-Circle", href: "/mobi-circle" },
    { label: "Community", href: "/community" },
    { label: "Biz-Catalogue", href: "/biz-catalogue" },
    { label: "E-Library", href: `/profile/${currentUserId}#contents` },
    { label: "Adverts Log", href: "/adverts-log" },
  ];

  // Featured top advert (mocked — real ad pool plugs in here later)
  const heroAd = {
    advertiser: "GoCom Taxi",
    tagline: "Ride smart. Stay better.",
    headline: "Provides an elite way to travel for an everyday price",
    body: "Connecting you affordably to where you want to be.",
    bullets: ["Move faster", "Save bigger", "Live better"],
    image:
      "https://images.unsplash.com/photo-1549921296-3a6b3ec0e13b?w=1200&q=80",
    ctaUrl: "#",
  };

  if (!profile) {
    return (
      <div className="space-y-3">
        <Card className="overflow-hidden rounded-3xl">
          <div className="h-[150px] sm:h-[180px] bg-muted animate-pulse" />
          <div className="p-4 space-y-3">
            <div className="flex items-end gap-3">
              <div className="h-24 w-24 rounded-full bg-muted animate-pulse" />
              <div className="flex-1 space-y-2">
                <div className="h-4 w-1/2 bg-muted animate-pulse rounded" />
                <div className="h-3 w-1/3 bg-muted animate-pulse rounded" />
              </div>
            </div>
          </div>
        </Card>
      </div>
    );
  }

  return (
    <div className="space-y-3">
      {/* ============ HERO BLOCK ============ */}
      <Card className="overflow-hidden rounded-3xl shadow-[0_6px_20px_-8px_hsl(var(--primary)/0.45)]">
        {/* Top Wall Banner — user-managed rotating slideshow (hidden in embedded/profile mode) */}
        {!embed && (
        <div className="m-2 mb-0 border-[5px] border-[hsl(212_95%_50%)] rounded-2xl overflow-hidden">
          <WallBannerSlideshow
            ownerId={currentUserId}
            scope="home"
            fallbackImage={heroAdBanner}
            fallbackAlt={`${heroAd.advertiser} — ${heroAd.headline}`}
            isOwner
            heightClass="h-[150px] sm:h-[180px]"
            onManage={() => setWallBannerManagerOpen(true)}
            onChangeFallback={() => setWallBannerManagerOpen(true)}
            onOpenViewer={(slide) => {
              const active = getActiveSlidesFor(currentUserId, "home");
              const list = active.length ? active : [slide];
              setViewerItems(
                list.map((s) => ({
                  id: s.id,
                  url: s.mediaUrl,
                  type: s.mediaType,
                  author: profile.fullName,
                  title: s.caption,
                  durationMs: (s.displaySeconds || 5) * 1000,
                }) as MediaItem),
              );
              setViewerStartIndex(Math.max(0, list.findIndex((s) => s.id === slide.id)));
              setBannerViewerOpen(true);
            }}
          />
        </div>
        )}

        {/* Identity Row — overlapping avatar */}
        <div className={embed ? "px-3 pb-3 pt-3 relative" : "px-3 pb-3 -mt-12 relative"}>
          {!embed && (<>
          <div className="flex items-end gap-3">
            {/* Avatar with online dot — nudged right, slightly larger */}
            <div className="relative shrink-0 ml-2">
              <Avatar className="h-24 w-24 border-4 border-card shadow-md">
                <AvatarImage src={profile.avatar} alt={profile.fullName} />
                <AvatarFallback>{profile.username.substring(0, 2)}</AvatarFallback>
              </Avatar>
              <span
                className="absolute bottom-1.5 right-1.5 h-4 w-4 rounded-full bg-green-500 ring-2 ring-card"
                aria-label="Online"
              />
              {/* Verified badge at bottom of avatar */}
              <span className="absolute -bottom-1.5 left-1/2 -translate-x-1/2 inline-flex items-center gap-0.5 bg-black/55 text-white text-[9px] font-bold px-1.5 py-[2px] rounded-full ring-2 ring-card whitespace-nowrap">
                <BadgeCheck className="h-2.5 w-2.5 fill-green-400 text-white" />
                Verified
              </span>
            </div>

            {/* Date/time on top, greeting below */}
            <div className="flex-1 min-w-0 pb-1.5 flex flex-col gap-1">
              <p className="text-[13px] font-medium text-muted-foreground tabular-nums whitespace-nowrap leading-tight">
                {liveDate} · {liveTime}
              </p>
              <p className="text-[15px] font-bold text-destructive leading-tight whitespace-nowrap">
                {profile.greeting?.trim() || (() => {
                  const h = now.getHours();
                  const part = h < 12 ? "morning" : h < 17 ? "afternoon" : h < 21 ? "evening" : "night";
                  return `Good ${part}!`;
                })()}
              </p>
            </div>
          </div>

          {/* Full Name + Badges — under avatar */}
          <div className="mt-2 flex items-center gap-2 flex-wrap">
            <h2 className="text-lg font-bold tracking-tight truncate">
              {profile.fullName}
            </h2>
            <UserTagBadges userId={currentUserId} />
          </div>

          {/* Nav row */}
          <div className="mt-3 pt-2 border-t flex flex-nowrap items-center overflow-x-auto scrollbar-hide">
            {primaryLinks.map((link) => (
              <span key={link.label} className="flex items-center flex-shrink-0">
                <Link
                  to={link.href}
                  className="text-base font-semibold text-foreground hover:text-primary transition-colors whitespace-nowrap"
                  onClick={(e) => handleLinkClick(e, link.href)}
                >
                  {link.label}
                </Link>
                <span className="text-muted-foreground px-2">|</span>
              </span>
            ))}

            {/* Friends */}
            <span className="flex items-center flex-shrink-0">
              <DropdownMenu onOpenChange={(open) => !open && setFriendsMenuView("main")}>
                <DropdownMenuTrigger asChild>
                  <button className="text-base font-semibold text-foreground hover:text-primary transition-colors whitespace-nowrap">
                    Friends
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent
                  align="start"
                  side="bottom"
                  sideOffset={5}
                  className="bg-card z-50 w-48"
                >
                  {friendsMenuView === "main" ? (
                    <>
                      <DropdownMenuItem asChild className="text-base font-medium text-primary">
                        <Link to={`/profile/${currentUserId}#friends`} className="cursor-pointer">
                          Friends
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        className="text-base font-medium text-primary cursor-pointer flex justify-between items-center"
                        onSelect={(e) => {
                          e.preventDefault();
                          setFriendsMenuView("requests");
                        }}
                      >
                        Friend Requests
                        <span className="ml-auto">&gt;</span>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild className="text-base font-medium text-primary">
                        <Link to="/friends/find" className="cursor-pointer">
                          Find Friends
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild className="text-base font-medium text-primary">
                        <Link to="/friends/invite" className="cursor-pointer">
                          Invite People
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild className="text-base font-medium text-primary">
                        <Link to="/friends/referred" className="cursor-pointer">
                          Referred Friends
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem
                        className="text-base font-medium text-primary cursor-pointer flex justify-between items-center"
                        onSelect={(e) => {
                          e.preventDefault();
                          setFriendsMenuView("birthdays");
                        }}
                      >
                        Friends' Birthdays
                        <span className="ml-auto">&gt;</span>
                      </DropdownMenuItem>
                    </>
                  ) : friendsMenuView === "requests" ? (
                    <>
                      <DropdownMenuItem
                        className="text-base font-medium text-primary cursor-pointer"
                        onSelect={(e) => {
                          e.preventDefault();
                          setFriendsMenuView("main");
                        }}
                      >
                        <ChevronLeft className="h-4 w-4 mr-2" />
                        Back
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild className="text-base font-medium text-primary">
                        <Link to="/friends/requests/received" className="cursor-pointer">
                          Received Requests
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild className="text-base font-medium text-primary">
                        <Link to="/friends/requests/sent" className="cursor-pointer">
                          Sent Requests
                        </Link>
                      </DropdownMenuItem>
                    </>
                  ) : (
                    <>
                      <DropdownMenuItem
                        className="text-base font-medium text-primary cursor-pointer"
                        onSelect={(e) => {
                          e.preventDefault();
                          setFriendsMenuView("main");
                        }}
                      >
                        <ChevronLeft className="h-4 w-4 mr-2" />
                        Back
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild className="text-base font-medium text-primary">
                        <Link to="/friends/birthdays?range=all" className="cursor-pointer">
                          All Birthdays
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild className="text-base font-medium text-primary">
                        <Link to="/friends/birthdays?range=today" className="cursor-pointer">
                          Today
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild className="text-base font-medium text-primary">
                        <Link to="/friends/birthdays?range=tomorrow" className="cursor-pointer">
                          Tomorrow
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild className="text-base font-medium text-primary">
                        <Link to="/friends/birthdays?range=yesterday" className="cursor-pointer">
                          Yesterday
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild className="text-base font-medium text-primary">
                        <Link to="/friends/birthdays?range=next-week" className="cursor-pointer">
                          Next Week
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild className="text-base font-medium text-primary">
                        <Link to="/friends/birthdays?range=last-week" className="cursor-pointer">
                          Last Week
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild className="text-base font-medium text-primary">
                        <Link to="/friends/birthdays?range=next-month" className="cursor-pointer">
                          Next Month
                        </Link>
                      </DropdownMenuItem>
                      <DropdownMenuItem asChild className="text-base font-medium text-primary">
                        <Link to="/friends/birthdays?range=last-month" className="cursor-pointer">
                          Last Month
                        </Link>
                      </DropdownMenuItem>
                    </>
                  )}
                </DropdownMenuContent>
              </DropdownMenu>
              <span className="text-muted-foreground px-2">|</span>
            </span>

            {/* Albums */}
            <span className="flex items-center flex-shrink-0">
              <Link
                to={`/profile/${currentUserId}#albums`}
                className="text-base font-semibold text-foreground hover:text-primary transition-colors whitespace-nowrap"
              >
                Albums
              </Link>
              <span className="text-muted-foreground px-2">|</span>
            </span>

            {/* More */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="text-base font-semibold text-foreground hover:text-primary transition-colors inline-flex items-center gap-1 flex-shrink-0">
                  <MoreHorizontal className="h-5 w-5" />
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="start" className="bg-card z-50 w-48">
                {moreLinks.map((link) => (
                  <DropdownMenuItem
                    key={link.label}
                    asChild
                    className="text-base font-medium text-primary"
                  >
                    <Link
                      to={link.href}
                      className="cursor-pointer"
                      onClick={(e) => handleLinkClick(e, link.href, link.action)}
                    >
                      {link.label}
                    </Link>
                  </DropdownMenuItem>
                ))}
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          {/* Search */}
          <div className="mt-3 flex items-center gap-2">
            <div className="relative flex-1">
              <Input
                placeholder="Search anything on Mobiface"
                className="h-11 rounded-full bg-muted/40 border-muted-foreground/20 pl-4 pr-4 text-[15px]"
              />
            </div>
            <Button
              size="icon"
              className="h-11 w-11 rounded-full shrink-0 shadow-sm"
              aria-label="Search"
            >
              <Search className="h-5 w-5" />
            </Button>
          </div>
          </>)}

          {/* ============ POSTING AREA ============ */}
          <div className="mt-3">
            {/* Section tabs */}
            <div className="flex items-center gap-2 overflow-x-auto scrollbar-hide -mx-1 px-1 pb-1">
              {(["Stories", "Vibes & Flexing", "Breaking News"] as const).map((t) => {
                const active = activeFeedTab === t;
                return (
                  <button
                    key={t}
                    type="button"
                    onClick={() => {
                      // Switch the posting area content in place — no page jump.
                      setActiveFeedTab(t);
                      setFeaturedPublicIdx(0);
                    }}
                    className={`shrink-0 h-9 px-3 rounded-md text-[13px] font-bold border-2 transition-colors touch-manipulation ${
                      active
                        ? "bg-green-600 text-white border-green-600 shadow-sm"
                        : "bg-card text-foreground border-border hover:border-green-500/60"
                    }`}
                  >
                    {t}
                  </button>
                );
              })}
            </div>
            <div className="h-px bg-green-500/40 mt-1 mb-3" />

            {/* ============ VIBES & FLEXING VIEW ============
                Image-first layout: one big featured vibe on the left with a (+)
                badge, a "Post & Share" button top-right, and a compact grid of
                vibe thumbnails below it. Footer cycles vibes with ◄ / ► arrows. */}
            {activeFeedTab === "Vibes & Flexing" && (
              <div className="rounded-lg overflow-hidden">
                <div className="grid grid-cols-[48%_1fr] gap-2 items-stretch">
                  {/* ===== Area A — the User's OWN vibes (latest on display) ===== */}
                  <button
                    type="button"
                    onClick={() => featuredPost && setOwnPostsViewerOpen(true)}
                    className="relative bg-muted rounded-lg overflow-hidden border-[3px] border-[hsl(212_95%_50%)] shadow-sm active:scale-[0.98] transition-transform touch-manipulation focus:outline-none focus-visible:ring-2 focus-visible:ring-[hsl(212_95%_50%)]"
                    aria-label="View your vibes"
                  >
                    {featuredPost ? (
                      <img
                        key={featuredPost.id || "my-latest-vibe"}
                        src={featuredPost.imageUrl}
                        alt={featuredPost.title}
                        className="w-full h-full object-cover aspect-[3/5] transition-opacity duration-300 pointer-events-none"
                        loading="lazy"
                      />
                    ) : (
                      <div className="aspect-[3/5] w-full flex items-center justify-center text-center text-[12px] text-muted-foreground px-2 pointer-events-none">
                        {canEdit
                          ? "Your vibes will show here. Tap + to post your first one."
                          : "No vibes posted yet."}
                      </div>
                    )}
                    <span className="absolute top-1.5 left-1.5 inline-flex items-center gap-1 rounded-md bg-black/55 px-1.5 py-0.5 text-[10px] font-semibold text-white backdrop-blur-sm pointer-events-none">
                      <Maximize2 className="h-3 w-3" />
                      {canEdit ? "My Vibes" : "Vibes"}
                    </span>
                    {/* (+) → action menu: Edit Post / Create New Post / View my Posts (owner only) */}
                    {canEdit && (
                      <span
                        onClick={(e) => {
                          e.stopPropagation();
                          setOwnActionsOpen(true);
                        }}
                        role="button"
                        tabIndex={0}
                        onKeyDown={(e) => {
                          if (e.key === "Enter" || e.key === " ") {
                            e.preventDefault();
                            e.stopPropagation();
                            setOwnActionsOpen(true);
                          }
                        }}
                        aria-label="Open post options"
                        className="absolute bottom-1.5 right-1.5 h-8 w-8 rounded-full bg-[hsl(212_95%_50%)] text-white flex items-center justify-center shadow ring-2 ring-card active:scale-95 touch-manipulation"
                      >
                        <Plus className="h-5 w-5" />
                      </span>
                    )}
                  </button>

                  {/* ===== Area B — everyone's vibes (auto-scrolling) ===== */}
                  <div className="flex flex-col gap-2 min-w-0">
                    {canEdit && (
                      <button
                        type="button"
                        onClick={openComposerBlank}
                        className="bg-[hsl(212_95%_50%)] text-white rounded-md px-2.5 py-2.5 flex items-center justify-center gap-2 text-[13px] font-bold leading-tight active:opacity-90 touch-manipulation shadow-sm"
                      >
                        <span className="truncate">Post &amp; Share your Vibe now</span>
                        <Images className="h-4 w-4 shrink-0" />
                      </button>
                    )}

                    <div
                      ref={vibeStripRef}
                      className="flex flex-row gap-1.5 flex-1 min-h-0 overflow-x-auto overflow-y-hidden touch-pan-x overscroll-x-contain [-webkit-overflow-scrolling:touch] [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
                    >
                      {communityVibes.map((post, i) => {
                        const mine = (post as any).userId === currentUserId;
                        return (
                          <button
                            key={`vibe-b-${i}-${post.id ?? i}`}
                            type="button"
                            onClick={() => openAllVibes(i)}
                            className="relative shrink-0 h-full w-[46%] rounded-md overflow-hidden bg-muted active:scale-95 transition-all touch-manipulation border border-[hsl(212_95%_50%)]/30 hover:opacity-100"
                            aria-label={`Open ${post.title || "vibe"} by ${(post as any).author || "user"}`}
                          >
                            <img
                              src={post.imageUrl}
                              alt={post.title}
                              className="h-full w-full object-cover"
                              loading="lazy"
                            />
                            {mine && (
                              <span className="absolute top-0.5 left-0.5 rounded bg-[hsl(212_95%_50%)] text-white text-[8px] font-bold px-1 py-0.5">
                                You
                              </span>
                            )}
                          </button>
                        );
                      })}
                    </div>
                  </div>
                </div>

                {/* Footer — ◄ scroll · see-all · scroll ► (arrows nudge the auto-scroll;
                    center text opens the full window of everybody's vibes) */}
                <div className="mt-3 flex items-center justify-center gap-3">
                  <button
                    type="button"
                    onClick={() => scrollVibeStrip("left")}
                    aria-label="Scroll vibes left"
                    className="h-8 w-8 rounded-full border flex items-center justify-center transition-all touch-manipulation bg-foreground text-background border-foreground shadow-md active:scale-90"
                  >
                    <ChevronLeft className="h-5 w-5" strokeWidth={3} />
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowcaseOpen(true)}
                    className="italic font-bold underline underline-offset-2 text-[13px] text-center leading-tight px-1 text-[hsl(212_95%_50%)] active:opacity-70 touch-manipulation"
                  >
                    Flex with more exciting Vibes
                  </button>
                  <button
                    type="button"
                    onClick={() => scrollVibeStrip("right")}
                    aria-label="Scroll vibes right"
                    className="h-8 w-8 rounded-full border flex items-center justify-center transition-all touch-manipulation bg-foreground text-background border-foreground shadow-md active:scale-90"
                  >
                    <ChevronRight className="h-5 w-5" strokeWidth={3} />
                  </button>
                </div>
              </div>
            )}


            {/* Featured post card — image left, [Post & Share button] + [storyline] stacked right.
                Image X + Storyline 1 are READ-ONLY; tapping either opens an action sheet
                with Edit Post / Create New Post. */}
            {activeFeedTab !== "Vibes & Flexing" && featuredPost && (
              <div className="rounded-lg overflow-hidden">
                <div className="grid grid-cols-[40%_1fr] gap-2 items-stretch">
                  {/* Left: own image — opens Edit/Create on own page, viewer elsewhere */}
                  <div
                    role="button"
                    tabIndex={0}
                    onClick={handleOwnPrimary}
                    onKeyDown={(e) => {
                      if (e.key === "Enter" || e.key === " ") {
                        e.preventDefault();
                        handleOwnPrimary();
                      }
                    }}
                    className="relative bg-muted rounded-lg overflow-hidden border-[3px] border-green-500/80 shadow-sm cursor-pointer active:scale-[0.98] transition-transform touch-manipulation focus:outline-none focus-visible:ring-2 focus-visible:ring-green-500"
                    aria-label={canEdit ? "Open post options: Edit Post or Create New Post" : "View posts"}
                  >
                    <img
                      key={featuredPost.id || safeFeaturedIdx}
                      src={featuredPost.imageUrl}
                      alt={featuredPost.title}
                      className="w-full h-full object-cover aspect-[4/5] transition-opacity duration-300 pointer-events-none"
                      loading="lazy"
                    />
                    <span className="absolute top-1.5 left-1.5 inline-flex items-center gap-1 rounded-md bg-black/55 px-1.5 py-0.5 text-[10px] font-semibold text-white backdrop-blur-sm pointer-events-none">
                      {canEdit ? <PenSquare className="h-3 w-3" /> : <Maximize2 className="h-3 w-3" />}
                      {canEdit ? "Tap to edit" : "Tap to view"}
                    </span>
                    {/* (+) → action menu: Edit Post / Create New Post / View my Posts (owner only) */}
                    {canEdit && (
                      <span
                        onClick={(e) => {
                          e.stopPropagation();
                          setOwnActionsOpen(true);
                        }}
                        role="button"
                        tabIndex={0}
                        onKeyDown={(e) => {
                          if (e.key === "Enter" || e.key === " ") {
                            e.preventDefault();
                            e.stopPropagation();
                            setOwnActionsOpen(true);
                          }
                        }}
                        aria-label="Open post options"
                        className="absolute bottom-1.5 right-1.5 h-7 w-7 rounded-full bg-foreground/85 text-background flex items-center justify-center shadow ring-2 ring-card active:scale-95 touch-manipulation"
                      >
                        <Plus className="h-4 w-4" />
                      </span>
                    )}
                  </div>

                  {/* Right column: stacked button + storyline (storyline is read-only opener) */}
                  <div className="flex flex-col gap-2 min-w-0">
                    {/* Post & Share button — quick shortcut to blank composer (owner only) */}
                    {canEdit && (
                      <button
                        type="button"
                        onClick={openComposerBlank}
                        className="bg-primary text-primary-foreground rounded-md px-2.5 py-2.5 text-center text-[15px] font-bold leading-tight truncate active:opacity-90 touch-manipulation shadow-sm"
                      >
                        {tabMeta.composeCta}
                      </button>
                    )}
                    {/* Storyline 1 — read-only opener (Edit/Create on own page, viewer elsewhere) */}
                    <div
                      role="button"
                      tabIndex={0}
                      onClick={handleOwnPrimary}
                      onKeyDown={(e) => {
                        if (e.key === "Enter" || e.key === " ") {
                          e.preventDefault();
                          handleOwnPrimary();
                        }
                      }}
                      className="flex-1 bg-lime-200/70 text-foreground p-2.5 text-left rounded-md active:opacity-90 touch-manipulation cursor-pointer focus:outline-none focus-visible:ring-2 focus-visible:ring-green-500 select-none"
                      aria-label={canEdit ? "Open post options: Edit Post or Create New Post" : "View posts"}
                    >
                      <p className="text-[15px] font-bold leading-snug">
                        {featuredPost.title || "Your Post or Content Description or Storyline here."}
                      </p>
                      <p className="text-[14px] leading-snug mt-1">
                        {(featuredPost as any).description ||
                          "However, the storyline may not just exceed certain word-counts or be made to be unnecessary"}
                        <span className="font-extrabold italic">…More</span>
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}


            {/* Public/Connection post — view-only wrapper.
                Inside it: the IMAGE opens the media viewer (enlarge),
                the STORYLINE text opens the full story details dialog.
                The outer card itself is NOT clickable. */}
            {activeFeedTab !== "Vibes & Flexing" && featuredPublicPost && (
              <div
                className="mt-2 rounded-lg overflow-hidden bg-purple-200/60 p-1.5"
                aria-label="Public post preview"
              >
                <div className="grid grid-cols-[40%_1fr] gap-2 items-stretch">
                  {/* IMAGE → opens MediaGalleryViewer */}
                  <button
                    type="button"
                    onClick={() => setViewerOpen(true)}
                    className="relative bg-muted rounded-md overflow-hidden border-2 border-red-500 cursor-pointer active:opacity-95 active:scale-[0.997] transition-transform touch-manipulation focus:outline-none focus-visible:ring-2 focus-visible:ring-red-500"
                    aria-label="Enlarge this post's media"
                  >
                    <img
                      key={featuredPublicPost.id || `pub-${safeFeaturedIdx}`}
                      src={featuredPublicPost.imageUrl}
                      alt={featuredPublicPost.title}
                      className="w-full h-full object-cover aspect-[4/5] transition-opacity duration-300 pointer-events-none"
                      loading="lazy"
                    />
                    <span className="absolute top-1.5 left-1.5 inline-flex items-center gap-1 rounded-md bg-black/55 px-1.5 py-0.5 text-[10px] font-semibold text-white backdrop-blur-sm pointer-events-none">
                      <Maximize2 className="h-3 w-3" />
                      Tap to enlarge
                    </span>
                  </button>

                  {/* STORYLINE → opens enlarged story details */}
                  <button
                    type="button"
                    onClick={() => setStoryDetailOpen(true)}
                    className="text-foreground p-2.5 text-left select-none cursor-pointer rounded-md hover:bg-purple-300/40 active:bg-purple-300/60 active:scale-[0.997] transition-all touch-manipulation focus:outline-none focus-visible:ring-2 focus-visible:ring-red-500"
                    aria-label="Read full story details"
                  >
                    <p className="text-[15px] font-bold leading-snug">
                      {featuredPublicPost.title || "Public Post or Content Description or Storyline here."}
                    </p>
                    <p className="text-[14px] leading-snug mt-1">
                      {(featuredPublicPost as any).description ||
                        "However, the storyline may not just exceed certain word-counts or be made to be unnecessarily bulky or voluminous in any case, or"}
                      <span className="font-extrabold italic text-primary">…More</span>
                    </p>
                    <p className="text-[11px] text-muted-foreground mt-1 italic">
                      by {(featuredPublicPost as any).author || "Public User"} · {featuredPublicPost.userId === currentUserId ? "Your post" : "Public / Connection"}
                    </p>
                  </button>
                </div>
              </div>
            )}



            {/* Scrollable thumbnail strip with real Play-style scroll arrows.
                Arrows scroll the media left/right and dim when nothing is left in
                that direction; the center label opens the full media window. */}
            {activeFeedTab !== "Vibes & Flexing" && myRecentPosts.length > 1 && (
              <ScrollableThumbStrip
                items={myRecentPosts.map((p, i) => ({
                  id: p.id || `thumb-${i}`,
                  imageUrl: p.imageUrl,
                  title: p.title,
                }))}
                activeIdx={safeFeaturedIdx}
                onSelect={(idx) => setFeaturedIdx(idx)}
                moreLabel={tabMeta.moreLabel}
                onSeeAll={() => setShowcaseOpen(true)}
                accent="0 84% 60%"
              />
            )}

            {/* Hidden gallery input */}
            <input
              ref={galleryInputRef}
              type="file"
              accept="image/*"
              className="hidden"
              onChange={handleGalleryFileChange}
            />
          </div>
        </div>
      </Card>

      {/* People You May Know (hidden in embedded/profile mode — the profile renders its own) */}
      {!embed && <PeopleYouMayKnow />}

      {/* Breaking News extras — Top Trending Headlines + Headlines you don't wanna miss */}
      {activeFeedTab === "Breaking News" && (
        <>
          <TopTrendingHeadlines />
          <HeadlinesYouDontWannaMiss />
        </>
      )}

      {/* Compose dialog */}
      <CreatePostDialog
        open={createPostOpen}
        onOpenChange={setCreatePostOpen}
        hideTrigger
        presetMediaUrl={presetMediaUrl}
        presetTitle={presetTitle}
      />

      {/* Bigger-window viewer for the featured media */}
      <MediaGalleryViewer
        open={viewerOpen}
        onOpenChange={setViewerOpen}
        items={myRecentPosts.map((p, i): MediaItem => ({
          id: p.id || `featured-${i}`,
          url: p.imageUrl,
          type: (p as any).type?.toLowerCase() === "video" ? "video" : (p as any).type?.toLowerCase() === "audio" ? "audio" : "photo",
          title: p.title,
          author: (p as any).author,
          authorImage: (p as any).authorProfileImage,
          authorUserId: (p as any).userId,
          description: (p as any).description,
          timestamp: (p as any).timestamp,
          likes: Number((p as any).likes) || 0,
          comments: Number((p as any).comments) || 0,
          followers: (p as any).followers,
          isOwner: (p as any).userId === currentUserId,
        }))}
        initialIndex={safeFeaturedIdx}
      />

      {/* Enlarged story details — opens when the storyline TEXT is tapped */}
      {featuredPublicPost && (
        <PostDetailDialog
          open={storyDetailOpen}
          onOpenChange={setStoryDetailOpen}
          post={{
            id:                 featuredPublicPost.id,
            title:              featuredPublicPost.title || "Public Post",
            subtitle:           (featuredPublicPost as any).subtitle,
            description:        (featuredPublicPost as any).description ||
                                "However, the storyline may not just exceed certain word-counts or be made to be unnecessarily bulky or voluminous in any case.",
            author:             (featuredPublicPost as any).author || "Public User",
            authorProfileImage: (featuredPublicPost as any).authorProfileImage,
            userId:             (featuredPublicPost as any).userId,
            status:             ((featuredPublicPost as any).status as "Online" | "Offline") || "Online",
            views:              String((featuredPublicPost as any).views ?? 0),
            comments:           String((featuredPublicPost as any).comments ?? 0),
            likes:              String((featuredPublicPost as any).likes ?? 0),
            followers:          (featuredPublicPost as any).followers,
            type:               (((featuredPublicPost as any).type as string)?.toLowerCase() === "video"   ? "Video"
                               : ((featuredPublicPost as any).type as string)?.toLowerCase() === "audio"   ? "Audio"
                               : ((featuredPublicPost as any).type as string)?.toLowerCase() === "pdf"     ? "PDF"
                               : ((featuredPublicPost as any).type as string)?.toLowerCase() === "url"     ? "URL"
                               : ((featuredPublicPost as any).type as string)?.toLowerCase() === "article" ? "Article"
                               : "Photo") as "Video" | "Article" | "Photo" | "Audio" | "PDF" | "URL",
            imageUrl:           featuredPublicPost.imageUrl,
            fee:                (featuredPublicPost as any).fee,
          }}
        />
      )}

      {/* ── Own Post action sheet (Edit / Create New) ── */}
      <ActionDialog open={ownActionsOpen} onOpenChange={setOwnActionsOpen}>
        <ActionDialogContent className="sm:max-w-sm rounded-2xl p-5">
          <ActionDialogHeader>
            <ActionDialogTitle className="text-lg">Post Options</ActionDialogTitle>
            <ActionDialogDescription>
              Choose what you want to do with your latest post.
            </ActionDialogDescription>
          </ActionDialogHeader>

          <div className="mt-2 flex flex-col gap-2">
            <button
              type="button"
              onClick={() => {
                setOwnActionsOpen(false);
                setEditPickerOpen(true);
              }}
              disabled={!featuredPost}
              className="w-full flex items-center gap-3 p-3 rounded-xl border-2 border-primary/30 bg-primary/5 hover:bg-primary/10 active:scale-[0.99] transition-all touch-manipulation text-left disabled:opacity-50"
            >
              <span className="h-10 w-10 rounded-full bg-primary text-primary-foreground flex items-center justify-center shrink-0">
                <PenSquare className="h-5 w-5" />
              </span>
              <span className="min-w-0">
                <span className="block text-[15px] font-bold text-foreground">Edit Post</span>
                <span className="block text-[12px] text-muted-foreground leading-snug">
                  Pick any of your posts to edit its images and/or text.
                </span>
              </span>
            </button>

            <button
              type="button"
              onClick={() => {
                setOwnActionsOpen(false);
                openComposerBlank();
              }}
              className="w-full flex items-center gap-3 p-3 rounded-xl border-2 border-green-500/30 bg-green-500/5 hover:bg-green-500/10 active:scale-[0.99] transition-all touch-manipulation text-left"
            >
              <span className="h-10 w-10 rounded-full bg-green-600 text-white flex items-center justify-center shrink-0">
                <FilePlus2 className="h-5 w-5" />
              </span>
              <span className="min-w-0">
                <span className="block text-[15px] font-bold text-foreground">Create New Post</span>
                <span className="block text-[12px] text-muted-foreground leading-snug">
                  Start a fresh post — images, video, audio, article or PDF.
                </span>
              </span>
            </button>

            <button
              type="button"
              onClick={() => {
                setOwnActionsOpen(false);
                setOwnPostsViewerOpen(true);
              }}
              disabled={!featuredPost}
              className="w-full flex items-center gap-3 p-3 rounded-xl border-2 border-blue-500/30 bg-blue-500/5 hover:bg-blue-500/10 active:scale-[0.99] transition-all touch-manipulation text-left disabled:opacity-50"
            >
              <span className="h-10 w-10 rounded-full bg-blue-600 text-white flex items-center justify-center shrink-0">
                <LayoutList className="h-5 w-5" />
              </span>
              <span className="min-w-0">
                <span className="block text-[15px] font-bold text-foreground">View my Posts</span>
                <span className="block text-[12px] text-muted-foreground leading-snug">
                  Open all the posts you've shared in a full window.
                </span>
              </span>
            </button>
          </div>
        </ActionDialogContent>
      </ActionDialog>

      {/* ── Edit existing own post dialog (edits the picked post, else latest) ── */}
      {(postToEdit || featuredPost) && (
        <EditPostDialog
          post={(postToEdit || featuredPost) as any}
          open={editPostOpen}
          onOpenChange={(o) => {
            setEditPostOpen(o);
            if (!o) setPostToEdit(null);
          }}
          onSave={() => {
            setEditPostOpen(false);
            setPostToEdit(null);
            window.dispatchEvent(new CustomEvent("postUpdated"));
          }}
        />
      )}

      {/* ── Edit picker — choose which of your posts to edit ── */}
      <ActionDialog open={editPickerOpen} onOpenChange={setEditPickerOpen}>
        <ActionDialogContent className="sm:max-w-lg rounded-2xl p-5 max-h-[85dvh] overflow-y-auto">
          <ActionDialogHeader>
            <ActionDialogTitle className="text-lg">Select a Post to Edit</ActionDialogTitle>
            <ActionDialogDescription>
              Tap any of your posts to open it in the editor.
            </ActionDialogDescription>
          </ActionDialogHeader>
          {myOwnPosts.length === 0 ? (
            <p className="mt-4 text-sm text-muted-foreground text-center py-6">
              You haven't shared any posts yet.
            </p>
          ) : (
            <div className="mt-3 grid grid-cols-3 gap-2">
              {myOwnPosts.map((post, i) => (
                <button
                  key={`edit-pick-${i}-${post.id ?? i}`}
                  type="button"
                  onClick={() => {
                    setPostToEdit(post);
                    setEditPickerOpen(false);
                    setEditPostOpen(true);
                  }}
                  className="relative aspect-square rounded-lg overflow-hidden border border-border bg-muted active:scale-95 transition-transform touch-manipulation"
                  aria-label={`Edit ${post.title || "post"}`}
                >
                  <img
                    src={post.imageUrl}
                    alt={post.title}
                    className="h-full w-full object-cover"
                    loading="lazy"
                  />
                  <span className="absolute inset-x-0 bottom-0 bg-black/55 text-white text-[10px] font-medium px-1 py-0.5 truncate">
                    {post.title || "Untitled"}
                  </span>
                </button>
              ))}
            </div>
          )}
        </ActionDialogContent>
      </ActionDialog>

      {/* ── Viewer: all of MY posts (Area A enlarge + "View my Posts") ── */}
      <MediaGalleryViewer
        open={ownPostsViewerOpen}
        onOpenChange={setOwnPostsViewerOpen}
        items={toMediaItems(myOwnPosts)}
        initialIndex={0}
        galleryType="post"
      />

      {/* ── Viewer: ALL vibes by everybody ("Flex with more exciting Vibes") ── */}
      <MediaGalleryViewer
        open={allVibesViewerOpen}
        onOpenChange={setAllVibesViewerOpen}
        items={toMediaItems(communityVibes)}
        initialIndex={allVibesStartIdx}
        galleryType="post"
      />

      {/* ── Full-window "see all" showcase with Filter (Stories / Vibes / Breaking News) ── */}
      <FeedShowcaseDialog
        open={showcaseOpen}
        onOpenChange={setShowcaseOpen}
        title={
          activeFeedTab === "Breaking News"
            ? "All Breaking News"
            : activeFeedTab === "Vibes & Flexing"
            ? "All Vibes & Flexing"
            : "All Stories"
        }
        items={showcaseMediaItems}
      />





      {/* Service Unavailable Dialog */}
      <Dialog />

      {/* Wall Banner — owner manager */}
      <WallBannerManagerDialog
        open={wallBannerManagerOpen}
        onOpenChange={setWallBannerManagerOpen}
        ownerId={currentUserId}
        scope="home"
      />

      {/* Wall Banner — big viewer for slides with "Open in viewer" action */}
      <MediaGalleryViewer
        open={bannerViewerOpen}
        onOpenChange={setBannerViewerOpen}
        items={viewerItems}
        initialIndex={viewerStartIndex}
        showActions={true}
        galleryType="banner"
        autoAdvance={true}
      />
    </div>
  );
};
