import { Menu } from "lucide-react";
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { ProfileDropdown } from "./ProfileDropdown";
import { NotificationsSheet } from "./NotificationsSheet";
import { MessagesSheet } from "./MessagesSheet";
import { useSidebar } from "@/components/ui/sidebar";
import mobifaceIcon from "@/assets/mobiface-icon.svg";
import mobifaceLogo from "@/assets/mobiface-logo.png";

export const Header = () => {
  const { toggleSidebar } = useSidebar();

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-card shadow-sm">
      <div className="flex h-[var(--header-height)] items-center justify-between px-4">
        <div className="flex items-center gap-3">
          <Button 
            variant="ghost" 
            size="iconLg"
            onClick={toggleSidebar}
            className="hover:bg-primary/10"
          >
            <Menu />
          </Button>
          <Link to="/dashboard" className="flex items-center gap-2 transition-opacity hover:opacity-80">
            {/* Full logo with text on all screens */}
            <img 
              src={mobifaceLogo} 
              alt="Mobiface" 
              className="h-12 w-auto"
            />
          </Link>
        </div>

        <div className="flex items-center gap-2">
          <NotificationsSheet />
          <MessagesSheet />
          <ProfileDropdown />
        </div>
      </div>
    </header>
  );
};
